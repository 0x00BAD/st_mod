import sys, os, math, time

### Classes instead of packages & modules to fit all in one file ###
class Util:
    class File:
        @staticmethod
        def read(path):
            try:
                f = open(path, 'r')
                lines = f.readlines()
                f.close()
                return lines
            except:
                pass

        @staticmethod
        def write(path, name, id, time):
            f = open(path, 'a+')
            f.write("Name=%s\n" % (name))
            f.write("ID=%i\n" % (id))
            f.write("Time=%i\n\n" % (time))
            f.close()

        @classmethod
        def removeLastLines(cls, path, num):
            allLines = cls.read(path)
            f = open(path, "w+")
            f.writelines(allLines[:-num])
            f.close()

    class Module:
        @classmethod
        def find(cls, name, atr):
            for module_name in sys.modules:
                if name == '*' or name in module_name:
                    try:
                        module = __import__(module_name)
                        getattr(module, atr)
                        return module
                    except:
                        pass

            return cls.find('*', atr)

        @staticmethod
        def dump(path):
            for m in sys.modules:
                f = open(path, 'a+')
                
                try:
                    module = __import__(m)

                    f.write("\n# %s\nimport %s\n" % (m, m))

                    for atr in dir(module):
                        atr_name = atr
                        atr = getattr(module, atr)

                        if callable(atr):
                            f.write("%s.%s() # %s\n" % (m, atr_name, type(atr)))
                            for sub_atr in ['__code__', '__defaults__', '__kwdefaults__']:
                                if sub_atr == '__code__':
                                    for co_atr in ['co_argcount', 'co_varnames', 'co_nlocals', 'co_names', 'co_cellvars', 'co_consts', 'co_freevars', 'co_posonlyargcount', 'co_kwonlyargcount']:
                                        try:
                                            f.write("%s.%s.%s.%s = %s\n" % (m, atr_name, sub_atr, co_atr, getattr(getattr(atr, sub_atr), co_atr)))
                                        except:
                                            pass
                                else:
                                    try:
                                        f.write("%s.%s.%s = %s\n" % (m, atr_name, sub_atr, getattr(atr, sub_atr)))
                                    except:
                                        pass
                        else:
                            f.write("%s.%s # %s\n" % (m, atr_name, type(atr)))
                except:
                    f.write("\n# ImportError: No module named %s\n" % (m))

                f.close()

### Import Metin2 modules ###
app = Util.Module.find('app', 'GetRandom')
item = Util.Module.find('item', 'GetItemName')
chr = Util.Module.find('chr', 'SetRotation')
chrmgr = Util.Module.find('chrmgr', 'SetMovingSpeed')
net = Util.Module.find('net', 'SendChatPacket')
player = Util.Module.find('player', 'SetAttackKeyState')
ui = Util.Module.find('ui', 'ThinBoard')
textTail = Util.Module.find('textTail', 'Pick')
chat = Util.Module.find('chat', 'AppendChat')
systemSetting = Util.Module.find('systemSetting', 'GetCurrentResolution')
playerSettingModule = Util.Module.find('playerSettingModule', 'SetGeneralMotions')
skill = Util.Module.find('skill', 'GetSkillName')
wndMgr = Util.Module.find('wndMgr', 'GetScreenWidth')
dbg = Util.Module.find('dbg', 'LogBox')
background = Util.Module.find('background', 'LoadMap')
shop = Util.Module.find('shop', 'IsPrivateShop')
grp = Util.Module.find('grp', 'SetInterfaceRenderState')
snd = Util.Module.find('snd', 'PlaySound')
effect = Util.Module.find('effect', 'SetPosition')
quest = Util.Module.find('quest', 'GetQuestIndex')
guild = Util.Module.find('guild', 'GetGuildLevel')
pack = Util.Module.find('pack', 'Exist')
ime = Util.Module.find('ime', 'MoveLeft')
miniMap = Util.Module.find('miniMap', 'GetGuildAreaID')

import time,game
from m2kmod.Modules import m2k_lib
import math

class TauAutobuyDialog(ui.ScriptWindow):

	Taus = [50821, 50822, 50823, 50824, 50825, 50826]
	PotionValue = [100, 5]
	State = 0
	
	def __init__(self):
		self.Board = ui.ThinBoard()
		self.Board.SetSize(200, 250)
		self.Board.SetPosition(52, 40)
		self.Board.AddFlag("movable")
		self.Board.Hide()
		
		self.comp = m2k_lib.Component()
		self.Header = self.comp.TextLine(self.Board, 'Potion-Buyer', 75, 8, self.comp.RGB(255, 255, 0))
		self.MinimumLabel = self.comp.TextLine(self.Board, 'Minimum Value:', 70, 60, self.comp.RGB(153, 178, 255))
		self.DurationLabel = self.comp.TextLine(self.Board, 'Duration:', 82, 110, self.comp.RGB(153, 178, 255))
		self.Value = self.comp.TextLine(self.Board, '+ 100', 85, 88, self.comp.RGB(255, 255, 255))
		self.Duration =self.comp.TextLine(self.Board, '10 Min.', 87, 138, self.comp.RGB(255, 255, 255))
		
		self.SlidbarValue = self.comp.SliderBar(self.Board, 0.5, self.SetConfig, 12, 75)
		self.SlidebarTime = self.comp.SliderBar(self.Board, 0.33, self.SetConfig, 12, 125)
		self.TauCombo = self.comp.ComboBox(self.Board, '<choose potion>', 35, 30, 135)

		self.Close = self.comp.Button(self.Board, '', 'Close', 183, 8, self.Board.Hide, 'd:/ymir work/ui/public/close_button_01.sub', 'd:/ymir work/ui/public/close_button_02.sub', 'd:/ymir work/ui/public/close_button_03.sub')
		self.BuyOn = self.comp.Button(self.Board, '', '', 80, 170, self.SetPotionStatus, 'm2kmod\Images\start_0.tga', 'm2kmod\Images\start_1.tga', 'm2kmod\Images\start_2.tga')
		self.BuyOff = self.comp.HideButton(self.Board, '', '', 80, 170, self.SetPotionStatus, 'm2kmod\Images\stop_0.tga', 'm2kmod\Images\stop_1.tga', 'm2kmod\Images\stop_2.tga')
		
		if player.GetName() != "":
			for Tau in self.Taus:
				self.TauCombo.InsertItem(1,str(Tau) + "  " + str(item.GetItemName(item.SelectItem(Tau))))
		
	def switch_state(self):
		if self.Board.IsShow():
			self.Board.Hide()
		else:
			self.Board.Show()
			
	
	def SetConfig(self):
		Value, Time = self.PotionValue
		MinValue = int(self.SlidbarValue.GetSliderPos() * 200)
		MinTime = int(self.SlidebarTime.GetSliderPos() * 30)
		if MinValue != Value:
			self.Value.SetText("+ " + str(MinValue))
		if MinTime != Time:
			self.Duration.SetText(str(MinTime) + " Min.")
			
		self.PotionValue = [MinValue, MinTime]
	
	def SetPotionStatus(self):
		if not shop.IsOpen():
			chat.AppendChat(7, "[m2k-Mod] Please open a Shop first!")
			return
		ItemIndex = self.TauCombo.GetCurrentText()
		if ItemIndex == "<choose potion>":
			chat.AppendChat(chat.CHAT_TYPE_INFO, "Please select an Item!")
			return
		if self.State:
			self.StopBuying()
		else:
			self.State = 1
			self.Spam = 0
			self.BuyOn.Hide()
			self.BuyOff.Show()
			self.StartBuying()
	

	def StartBuying(self):
		SelectedIndex = self.TauCombo.GetCurrentText()
		MinValue, MinTime = self.PotionValue
		MinTime = MinTime * 60
		PotionValue = int(SelectedIndex.split("  ")[0])
		
		for InventorySlot in xrange(player.INVENTORY_PAGE_SIZE*2):
			ItemIndex = player.GetItemIndex(InventorySlot)
			if PotionValue == ItemIndex:
				Value0, Value , Time = [player.GetItemMetinSocket(InventorySlot, i) for i in xrange(player.METIN_SOCKET_MAX_NUM)]
				if Value >= MinValue and Time >= MinTime:
					self.StopBuying()
					return
				else:
					net.SendShopSellPacket(InventorySlot)
		Slot = 0
		if shop.IsOpen():
			for EachShopSlot in xrange(shop.SHOP_SLOT_COUNT):
				ShopItemValue = shop.GetItemID(EachShopSlot)
				if ShopItemValue == int(PotionValue):
					Slot = EachShopSlot
					break
		else:
			chat.AppendChat(7, "[m2k-Mod] No Shop is open!")
			self.StopBuying()
			return
			
		if Slot != 0 and shop.IsOpen():	
			net.SendShopBuyPacket(Slot)
		else:
			chat.AppendChat(7, "[m2k-Mod] Cant find " + SelectedIndex.split("  ")[1] + " in shop!")
			self.StopBuying()
			return
		
		self.UpdateBuying = m2k_lib.WaitingDialog()			
		self.UpdateBuying.Open(1.0)
		self.UpdateBuying.SAFE_SetTimeOverEvent(self.StartBuying)
	
	def StopBuying(self):
		self.State = 0
		self.BuyOff.Hide()
		self.BuyOn.Show()
		self.UpdateBuying = m2k_lib.WaitingDialog()	
		self.UpdateBuying.Close()
						
#TauAutobuyDialog().Show()