
import sys
_chr = chr

import __builtin__ as buildin
try:
	import time
except:
	pass

def HasArguments(module, attrlist):
    for attr in attrlist:
        if not buildin.hasattr(module, attr):
            return False
    return True
# modules = sys.modules
	
# for modulename in modules:
# for modulename in sys.modules:


for modulename, module in iter(sys.modules.items()):
	# module = sys.modules[modulename]
    if HasArguments(module, ['clock', 'clock_getres', 'clock_gettime']):time = module
    if HasArguments(module, ['GetPlayTime']):player = module
    if HasArguments(module, ['GetNameByVID']):chr = module
    if HasArguments(module, ['DirectEnter']):net = module
    if HasArguments(module, ['SetCameraMaxDistance']):app = module
    if HasArguments(module, ['mouseController']):mouseModule = module
    if HasArguments(module, ['ArrangeShowingChat']):chat = module
    if HasArguments(module, ['ClearSlot']):wndMgr = module
    if HasArguments(module, ['GetCurrentMapName']):background = module
    if HasArguments(module, ['SetEmpireNameMode']):chrmgr = module
    if HasArguments(module, ['GetItemName', 'SelectItem']):item = module
    if HasArguments(module, ['ArrangeTextTail', 'RegisterChatTail']):textTail = module
    if HasArguments(module, ['ItemToolTip']):uiToolTip = module
    if HasArguments(module, ['GetGradeByVID']):nonplayer = module
    if HasArguments(module, ['OpenQuestWindow', 'GameWindow']):game = module
    if HasArguments(module, ['IsSoftwareCursor']):systemSetting = module
    if HasArguments(module, ['SelectAnswer']):event = module
    if HasArguments(module, ['ENVIRONMENT_NIGHT']):constInfo = module
    if HasArguments(module, ['GenerateColor']):grp = module
    if HasArguments(module, ['GenerateFromHandle']):grpImage = module
    if HasArguments(module, ['LogBox']):dbg = module
    if HasArguments(module, ['EnableCaptureInput', 'GetReading']):ime = module
    if HasArguments(module, ['GetSkillCoolTime', 'GetSkillLevelUpPoint']):skill = module
    if HasArguments(module, ['Exist', 'Get']):pack = module
    if HasArguments(module, ['SetGeneralMotions']):playerSettingModule = module
    if HasArguments(module, ['PlaySound']):snd = module
    if HasArguments(module, ['IsPrivateShop']):shop = module
    if HasArguments(module, ['APP_TITLE']):locale = module
    if HasArguments(module, ['APP_TITLE']):localeinfo = module
    if HasArguments(module, ['CharacterWindow']):uiCharacter = module
    if HasArguments(module, ['IsAtlas']):miniMap = module
    if HasArguments(module, ['InputDialog']):uiCommon = module
    if HasArguments(module, ['factorial']):math = module
    if HasArguments(module, ['BigBoard']):uiTip = module
    if HasArguments(module, ['AtlasWindow']):uiMiniMap = module
    if HasArguments(module, ['MARKADDR_DICT']):serverInfo = module
    if HasArguments(module, ['ScriptWindow']):ui = module
    if HasArguments(module, ['SAFEBOX_PAGE_SIZE']):safebox = module
    if HasArguments(module, ['ItemToolTip']):uiToolTip = module
    if HasArguments(module, ['Interface']):interfacemodule = module
    if HasArguments(module, ['CreateEffect']):effect = module
    if HasArguments(module, ['Clear']):quest = module
    if HasArguments(module, ['AUTH_ADD_MEMBER']):guild = module
    if HasArguments(module, ['GetExceptionString']):exception = module
    if HasArguments(module, ['O_APPEND']):os = module
    if HasArguments(module, ['WRAPPER_ASSIGNMENTS']):functools = module

import Movement
import OpenLib,eXLib
import FileManager,UIComponents
from BotBase import BotBase
from FileManager import boolean



class LevelBotDialog(BotBase):

	STATE_WAIT = 0
	STATE_LEVELING = 1

	TIME_WAIT = 0.5

	class LocationCondition:
		def __init__(self,level,locationX,locationY,map):
			self.level = level
			self.locationX = locationX
			self.locationY = locationY
			self.map = map

		def parseLocation(self,string):
			all = string.split("|")
			self.level = int(all[0].split(":")[1])
			self.locationX = int(all[1].split(":")[1])*100
			self.locationY = int(all[2].split(":")[1])*100
			self.map = all[3].split(":")[1]

		
		def __hash__(self):
			return self.level

		def __eq__(self, o):
			if isinstance(o,self.__class__):
				return self.level == o.level
			return self.level == o
		
		def __str__(self):
			return "Level:" +str(self.level) + "|X:"+str(int(self.locationX/100))+"|Y:"+str(int(self.locationY/100))+"|Map:"+str(self.map)


	def __init__(self):
		BotBase.__init__(self,self.TIME_WAIT,waitIsPlayerDead=True)
		self.Range = 20000
		self.startPosition = (0,0)
		self.goToCenter = False
		self.ignoreBlockedPosition = True

		#Location Changer
		self.allowLocChanger = False
		self.locations = set()


		self.levelState = self.STATE_LEVELING
		self.LoadSettings()
		self.BuildWindow()


	def BuildWindow(self):
		self.Board = ui.BoardWithTitleBar() 
		self.Board.SetPosition(52, 40)
		self.Board.SetSize(300, 380) 
		self.Board.SetTitleName("LevelBot")
		self.Board.AddFlag("movable")
		self.Board.SetCloseEvent(self.Close)
		self.Board.Hide()

		comp = UIComponents.Component()
		self.rangeLabel = comp.TextLine(self.Board, "Range", 25, 40, comp.RGB(255, 255, 255))
		self.slideRange = comp.SliderBar(self.Board, float(self.Range/20000.0), self.OnSlideRange,self.rangeLabel.GetLocalPosition()[0]+40,self.rangeLabel.GetLocalPosition()[1]+5)
		self.rangeNumLabel = comp.TextLine(self.Board, self.Range,self.slideRange.GetLocalPosition()[0] + 185, self.slideRange.GetLocalPosition()[1], comp.RGB(255, 255, 255))
		self.ignoreInWallsBtn = comp.OnOffButton(self.Board, '\t\t\t\t\t\t\tIgnore Mobs in Walls', "Don't attack mobs in walls", 20, 80,funcState=self.OnIgnoreInWall,defaultValue=int(self.ignoreBlockedPosition))
		self.goToCenterBtn = comp.OnOffButton(self.Board, '\t\t\tGo to center', "Go to center when no moobs near", 170, 80,funcState=self.OnGoToCenter,defaultValue=int(self.goToCenter))
		self.goToShopBtn = comp.OnOffButton(self.Board, '\t\tGo to shop', "Go to shop when inventory full", 20, 115,funcState=self.SetShopOnInvFull,defaultValue=int(self.allowShopOnFullInv))
		
		self.EnableButton = comp.OnOffButton(self.Board, '', '', 0,323,OffUpVisual=eXLib.PATH + 'OpenBot/Images/start_0.tga', OffOverVisual=eXLib.PATH + 'OpenBot/Images/start_1.tga', OffDownVisual=eXLib.PATH + 'OpenBot/Images/start_2.tga',OnUpVisual=eXLib.PATH + 'OpenBot/Images/stop_0.tga', OnOverVisual=eXLib.PATH + 'OpenBot/Images/stop_1.tga', OnDownVisual=eXLib.PATH + 'OpenBot/Images/stop_2.tga',funcState=self.OnStartStop)
		self.EnableButton.SetWindowHorizontalAlignCenter()

		#Location stuff
		self.labelChanger = comp.TextLine(self.Board, 'Location Changer', 110, 140, comp.RGB(255, 255, 0))
		self.locationActivateBtn = comp.OnOffButton(self.Board, '\t\t\t\t\tChange location', "Change locations based on level", 20, 160,funcState=self.OnLocationBtnChange,defaultValue=int(self.allowLocChanger))
		self.removeLocButton = comp.Button(self.Board, 'Remove', 'Remove selected entry', 212, 160,  self.OnRemoveSelected, 'd:/ymir work/ui/public/Middle_Button_01.sub', 'd:/ymir work/ui/public/Middle_Button_02.sub', 'd:/ymir work/ui/public/Middle_Button_03.sub')
		self.barItems, self.fileListBox, self.ScrollBar = comp.ListBoxEx2(self.Board, 20, 187, 235, 100)
		self.levelSlotBar, self.levelEditLine = comp.EditLine(self.Board, '', 182, 295, 30, 15, 3)
		self.locationText = comp.TextLine(self.Board, 'Current location starting on level ', 27, 295, comp.RGB(255, 255, 255))
		self.addLocButton = comp.Button(self.Board, 'Add', '', 222, 293,  self.OnAddLocation, 'd:/ymir work/ui/public/small_Button_01.sub', 'd:/ymir work/ui/public/small_Button_02.sub', 'd:/ymir work/ui/public/small_Button_03.sub')
		
		#Init
		self.OnSlideRange()
		self.UpdateLocationList()

	def LoadSettings(self):
		self.Range = int(FileManager.ReadConfig("LevelRange"))
		self.goToCenter = boolean(FileManager.ReadConfig("LevelGoToCenter"))
		self.ignoreBlockedPosition = boolean(FileManager.ReadConfig("LevelIgnoreBlockedPos"))
		self.allowShopOnFullInv = boolean(FileManager.ReadConfig("LevelShopFullInv"))
		self.allowLocChanger = boolean(FileManager.ReadConfig("LevelAllowLocation"))
		locs = FileManager.LoadListFile(FileManager.CONFIG_LOCATION_CHANGER)
		for loc in locs:
			this_loc = self.LocationCondition(0,0,0,0)
			try:
				this_loc.parseLocation(loc)
				self.locations.add(this_loc)
			except Exception:
				continue

	def SaveSettings(self):
		#chat.AppendChat(3,str(self.Range))
		FileManager.WriteConfig("LevelRange", str(self.Range))
		FileManager.WriteConfig("LevelGoToCenter", str(self.goToCenter))
		FileManager.WriteConfig("LevelIgnoreBlockedPos", str(self.ignoreBlockedPosition))
		FileManager.WriteConfig("LevelShopFullInv", str(self.allowShopOnFullInv))
		FileManager.WriteConfig("LevelAllowLocation", str(self.allowLocChanger))
		FileManager.SaveListFile(FileManager.CONFIG_LOCATION_CHANGER,self.locations)
		FileManager.Save()


	#UI
	def OnRemoveSelected(self):
		_item = self.fileListBox.GetSelectedItem()
		if _item == None:
			return
		lvl = int(_item.GetText().split("|")[0].split(":")[1])
		self.locations.remove(lvl)
		self.UpdateLocationList()

	def OnLocationBtnChange(self,val):
		self.allowLocChanger = val

	def OnAddLocation(self):
		level = int(self.levelEditLine.GetText())
		position = player.GetMainCharacterPosition()
		curr_map = background.GetCurrentMapName()
		loc = self.LocationCondition(level,position[0],position[1],curr_map)
		self.locations.add(loc)
		self.UpdateLocationList()

	def UpdateLocationList(self):
		self.fileListBox.RemoveAllItems()
		for loc in sorted(self.locations,key=lambda x:x.level):
			self.fileListBox.AppendItem(OpenLib.Item(str(loc)))

	def OnIgnoreInWall(self,val):
		self.ignoreBlockedPosition = val

	def OnGoToCenter(self,val):
		self.goToCenter = val

	def OnSlideRange(self):
		self.Range = int(self.slideRange.GetSliderPos()*20000)
		self.rangeNumLabel.SetText(str(self.Range))

	def OnStartStop(self,val):
		if val:
			self.Start()
		else:
			self.Stop()


	
	#Logic
	def Close(self):
		self.SaveSettings()
		self.Board.Hide()

	def SetStateLeveling(self):
		self.levelState = self.STATE_LEVELING
	
	def SetStateWait(self):
		self.levelState = self.STATE_WAIT

	def GetNextMonster(self):
		(closest_vid,_dist) = (0,999999999)
		my_pos = player.GetMainCharacterPosition()
		for vid in eXLib.InstancesList:
			if not chr.HasInstance(vid):
				continue

			if eXLib.IsDead(vid):
				continue

			_type = chr.GetInstanceType(vid)
			if self.ignoreBlockedPosition and eXLib.IsPositionBlocked(my_pos[0],my_pos[1]):
				continue

			if _type != OpenLib.MONSTER_TYPE:
				continue

			if OpenLib.dist(self.startPosition[0],self.startPosition[1],my_pos[0],my_pos[1]) > self.Range:
				continue
			
			this_dist = OpenLib.dist(my_pos[0],my_pos[1],my_pos[0],my_pos[1])

			if this_dist < _dist:
				_dist = this_dist
				closest_vid = vid
		
		return closest_vid

	def _PositionArriveCallback(self):
		self.SetStateLeveling()

	
	def CheckChangeLocation(self):
		currLevel = player.GetStatus(player.LEVEL)
		resultLoc = 0
		for loc in self.locations:
			if loc.level > currLevel:
				continue
			if resultLoc == 0:
				resultLoc = loc
				continue
			if  loc.level > resultLoc.level:
				resultLoc = loc
		if resultLoc != 0 and ( int(resultLoc.locationX) != int(self.startPosition[0]) or int(resultLoc.locationY) != int(self.startPosition[1]) or background.GetCurrentMapName() != resultLoc.map):
			chat.AppendChat(3,"Going to " + str(resultLoc.map) + " X:" + str(resultLoc.locationX) + " Y:" + str(resultLoc.locationY))
			self.SetStateWait()
			Movement.GoToPositionAvoidingObjects(resultLoc.locationX,resultLoc.locationY,callback=self._PositionArriveCallback,mapName=resultLoc.map)
			self.startPosition = (resultLoc.locationX,resultLoc.locationY)
			return True
		return False

	
	#Abstract Functions
	def CanPause(self):
		if self.levelState == self.STATE_WAIT:
			return False
		return True

	def Resume(self):
		self.SetStateLeveling()
		pass

	def Pause(self):
		# player.SetAttackKeyState(False)
		pass

	def StartBot(self):
		self.startPosition = player.GetMainCharacterPosition()
		self.Resume()

	def StopBot(self):
		self.Pause()

	def Frame(self):
		if self.levelState == self.STATE_LEVELING:
			if self.allowLocChanger and self.CheckChangeLocation():
				return
			monster = self.GetNextMonster()
			if monster != 0:
				OpenLib.AttackTarget(monster)
			elif self.goToCenter:
				Movement.GoToPositionAvoidingObjects(self.startPosition[0],self.startPosition[1])
		
		elif self.levelState == self.STATE_WAIT:
			return

def switch_state():
	if not level.Board.IsShow():
		level.Board.Show()
	else:
		level.Close()


level = LevelBotDialog()
level.Show()