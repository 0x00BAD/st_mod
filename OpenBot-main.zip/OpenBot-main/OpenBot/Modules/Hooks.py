
import sys
_chr = chr

import __builtin__ as buildin
try:
	import time
except:
	pass

def HasArguments(module, attrlist):
    for attr in attrlist:
        if not buildin.hasattr(module, attr):
            return False
    return True
# modules = sys.modules
	
# for modulename in modules:
# for modulename in sys.modules:


for modulename, module in iter(sys.modules.items()):
	# module = sys.modules[modulename]
    if HasArguments(module, ['clock']):time = module
    if HasArguments(module, ['GetPlayTime']):player = module
    if HasArguments(module, ['GetNameByVID']):chr = module
    if HasArguments(module, ['DirectEnter']):net = module
    if HasArguments(module, ['SetCameraMaxDistance']):app = module
    if HasArguments(module, ['mouseController']):mouseModule = module
    if HasArguments(module, ['ArrangeShowingChat']):chat = module
    if HasArguments(module, ['ClearSlot']):wndMgr = module
    if HasArguments(module, ['GetCurrentMapName']):background = module
    if HasArguments(module, ['SetEmpireNameMode']):chrmgr = module
    if HasArguments(module, ['GetItemName', 'SelectItem']):item = module
    if HasArguments(module, ['ArrangeTextTail', 'RegisterChatTail']):textTail = module
    if HasArguments(module, ['ItemToolTip']):uiToolTip = module
    if HasArguments(module, ['GetGradeByVID']):nonplayer = module
    if HasArguments(module, ['OpenQuestWindow', 'GameWindow']):game = module
    if HasArguments(module, ['IsSoftwareCursor']):systemSetting = module
    if HasArguments(module, ['SelectAnswer']):event = module
    if HasArguments(module, ['ENVIRONMENT_NIGHT']):constInfo = module
    if HasArguments(module, ['GenerateColor']):grp = module
    if HasArguments(module, ['GenerateFromHandle']):grpImage = module
    if HasArguments(module, ['LogBox']):dbg = module
    if HasArguments(module, ['EnableCaptureInput', 'GetReading']):ime = module
    if HasArguments(module, ['GetSkillCoolTime', 'GetSkillLevelUpPoint']):skill = module
    if HasArguments(module, ['Exist', 'Get']):pack = module
    if HasArguments(module, ['SetGeneralMotions']):playerSettingModule = module
    if HasArguments(module, ['PlaySound']):snd = module
    if HasArguments(module, ['IsPrivateShop']):shop = module
    if HasArguments(module, ['APP_TITLE']):locale = module
    if HasArguments(module, ['APP_TITLE']):localeinfo = module
    if HasArguments(module, ['CharacterWindow']):uiCharacter = module
    if HasArguments(module, ['IsAtlas']):miniMap = module
    if HasArguments(module, ['InputDialog']):uiCommon = module
    if HasArguments(module, ['factorial']):math = module
    if HasArguments(module, ['BigBoard']):uiTip = module
    if HasArguments(module, ['AtlasWindow']):uiMiniMap = module
    if HasArguments(module, ['MARKADDR_DICT']):serverInfo = module
    if HasArguments(module, ['ScriptWindow']):ui = module
    if HasArguments(module, ['SAFEBOX_PAGE_SIZE']):safebox = module
    if HasArguments(module, ['ItemToolTip']):uiToolTip = module
    if HasArguments(module, ['Interface']):interfacemodule = module
    if HasArguments(module, ['CreateEffect']):effect = module
    if HasArguments(module, ['Clear']):quest = module
    if HasArguments(module, ['AUTH_ADD_MEMBER']):guild = module
    if HasArguments(module, ['GetExceptionString']):exception = module
    if HasArguments(module, ['O_APPEND']):os = module
    if HasArguments(module, ['WRAPPER_ASSIGNMENTS']):functools = module


import functools
import OpenLog
import game

"""
Hooking module.
"""

#The current phase.
CURRENT_PHASE = 5
phaseCallbacks = {}
GAME_WINDOW = 0

class Hook():
	"""
	Hook class that allows to replace functions in modules.
	"""
	def __init__(self,toHookFunc,replaceFunc):
		self.originalFunc = toHookFunc
		self.replaceFunc = replaceFunc
		self.functionName = str(toHookFunc.__name__)
		self.functionOwner = self.GetFunctionOwner(toHookFunc)
		self.isHooked = False



	def GetFunctionOwner(self,func):
		"""
		Return the object owner of the function 

		Args:
			func ([function]): a function.

		Returns:
			[object]: Return the object owner of the function.
		"""
		try:
			owner = func.im_class		#In case of a class function
		except AttributeError:
			owner = sys.modules[func.__module__]
		
		return owner


	def CallOriginalFunction(self,*args,**kwargs):
		"""
		Call the original function before the hook.
		Returns:
			[args]: the arguments of the function.
		"""
		@functools.wraps(self.originalFunc)
		def run(*args, **kwargs):
			return self.originalFunc(*args, **kwargs)
		return run(*args,**kwargs)
		
	def HookFunction(self):
		"""
		Hook the function.
		"""
		if self.isHooked:
			return
		self.isHooked = True
		setattr(self.functionOwner, self.functionName, self.replaceFunc)

	def UnhookFunction(self):
		"""
		Remove the hook and put the original function.
		"""
		if self.isHooked == False:
			return
		self.isHooked = False
		#chat.AppendChat(3,"Function Owner: " + str(self.functionOwner.__name__) + "Function Name: " + str(self.functionName))
		setattr(self.functionOwner, self.functionName, self.originalFunc)

def skipFunc(*args):
	"""
	Function that doesn nothing.
	"""
	pass 

def phaseIntercept(*args,**kwargs):
	#printFuncNC(*args,**kwargs)
	global CURRENT_PHASE
	if len(args)>1 and args[1] != 0:
		CURRENT_PHASE = args[0]
	OpenLog.DebugPrint("PHASE: "+ str(CURRENT_PHASE))
	
	f = open('cur_phase',"w")
	f.write(str(CURRENT_PHASE))
	f.close()
	
	for callback_id in phaseCallbacks:
		callback = phaseCallbacks[callback_id]
		if callable(callback):
			callback(CURRENT_PHASE,args[1])
	phaseHook.CallOriginalFunction(*args,**kwargs)

def registerPhaseCallback(id,func):
	phaseCallbacks[id] = func

def deletePhaseCallback(id):
	if id in phaseCallbacks:
		del phaseCallbacks[id]

class SkipHook(Hook):
	def __init__(self,toHookFunc):
		Hook.__init__(self,toHookFunc,skipFunc)


def GameWindowIntercept(*args,**kwargs):
	#This is supposed to be run One Time, after this you can access "Current Window attribute from stream."
	import Hooks, Data
	if args[0] == 0:
		return
	#printFuncNC(*args,**kwargs)
	Data.GameWindow = args[0]
	Data.obj = Data.uiShortcut() #The Constructor resets player.SetGameWindow to original method thus removing the hook. 
	Hooks.GAME_WINDOW = args[0]
	player.SetGameWindow(*args, **kwargs)


def CheckAffectIntercept(*args,**kwargs):
    import Hooks, chr
	try:
		#printFuncNC(*args,**kwargs)
		if args[0] == chr.NEW_AFFECT_AUTO_USE:
				#chat.AppendChat(7,"Returned True for Auto Use")
				return True
		else:
			Hooks.checkAffectHook.CallOriginalFunction(*args, **kwargs)
	except:
		pass
import game

debugFunc = 0
questHook = SkipHook(game.GameWindow.OpenQuestWindow)
phaseHook = Hook(net.SetPhaseWindow,phaseIntercept)
gameWindowHook = Hook(player.SetGameWindow, GameWindowIntercept)
checkAffectHook = Hook(item.CheckAffect, CheckAffectIntercept)

def GetQuestHookObject():
	return questHook


def GetCurrentPhase():
	global CURRENT_PHASE
	return CURRENT_PHASE

def GetGameWindow():
	global GAME_WINDOW
	return GAME_WINDOW

def printFunc(*args,**kwargs):
	"""
	Print the arguments of a function to a debug.txt file.(In the game folder)
	"""
	with open("debug.txt","a") as f:
		#chat.AppendChat(3,"[DebugHook] Function called arguments:")
		f.write("[DebugHook] Function called arguments:\n")
		for i,arg in enumerate(args):
			f.write("[DebugHook] Arg "+ str(i) + ": "+ str(arg)+"\n")
			#chat.AppendChat(3,"[DebugHook] Arg "+ str(i) + ": "+ str(arg))
		f.write("\n")
	debugFunc.CallOriginalFunction(*args,**kwargs)

def printFuncNC(*args,**kwargs):
	"""
	Print the arguments of a function to a debug.txt file.(In the game folder)
	This happens without Calling the Original.
	"""
	with open("debug.txt","a") as f:
		#chat.AppendChat(3,"[DebugHook] Function called arguments:")
		f.write("[DebugHook] Function called arguments:\n")
		for i,arg in enumerate(args):
			f.write("[DebugHook] Arg "+ str(i) + ": "+ str(arg)+"\n")
			#chat.AppendChat(3,"[DebugHook] Arg "+ str(i) + ": "+ str(arg))
		f.write("\n")

#Print arguments of a function
def _debugHookFunctionArgs(func):
	global debugFunc
	debugFunc = Hook(func,printFunc)
	debugFunc.HookFunction()

def _debugUnhookFunctionArgs():
	debugFunc.UnhookFunction()

phaseHook.HookFunction()
gameWindowHook.HookFunction()
checkAffectHook.HookFunction()