#import Generel,Buffbot,Spambot,Energybot,Telehack,Inventorymanager,Itemcreator,InstantPickup,EQChanger,Info,Shopcreator,m2k_lib,m2k_hook,Global

#import m2kmod.Modules.Settings,m2kmod.Modules.Buffbot,m2kmod.Modules.Spambot,m2kmod.Modules.Fishbot,m2kmod.Modules.Energybot
#import m2kmod.Modules.Telehack,m2kmod.Modules.Inventorymanager,m2kmod.Modules.Itemcreator,m2kmod.Modules.InstantPickup,m2kmod.Modules.Generel
#import m2kmod.Modules.EQChanger,m2kmod.Modules.Info,m2kmod.Modules.Shopcreator,m2kmod.Modules.Mobscanner,m2kmod.Modules.CHChanger,m2kmod.Modules.Telehack