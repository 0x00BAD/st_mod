exec ('import sys')
import time
import os
import math

b = sys.modules.keys()
for i in range (len(b)):
    h=b[i]
    r=0
    for g in range(len(h)):
        if h[g] != '.':
            r=r+1
            if r==len(h):
                a=dir(__import__(b[i]))
                for y in range(len(a)):
                    if a[y]=='SET_DEFAULT_FOG_LEVEL':
                        constInfom=b[i]
                    if a[y]=='APP_TITLE':
                        localeinfom=b[i]
                    if a[y]=='APP_TITLE':
                        localem=b[i]
                    if a[y]=='GetGuildAreaID':
                        minimapm=b[i]
                    if a[y]=='MoveLeft':
                        imem=b[i]
                    if a[y]=='GetGuildLevel':
                        guildm=b[i]
                    if a[y]=='GetQuestIndex':
                        questm=b[i]
                    if a[y]=='SetPosition':
                        effectm=b[i]
                    if a[y]=='PlaySound':
                        sndm=b[i]
                    if a[y]=='SetInterfaceRenderState':
                        grpm=b[i]
                    if a[y]=='IsPrivateShop':
                        shopm=b[i]
                    if a[y]=='LoadMap':
                        backgroundm=b[i]
                    if a[y]=='LogBox':
                        dbgm=b[i]
                    if a[y]=='GetScreenWidth':
                        wndMgrm=b[i]
                    if a[y]=='GetSkillName':
                        skillm=b[i]
                    if a[y]=='SetGeneralMotions':
                        playerSettingModulem=b[i]
                    if a[y]=='GetCurrentResolution':
                        systemSettingm=b[i]
                    if a[y]=='AppendChat':
                        chatm=b[i]
                    if a[y]=='Pick':
                        textTailm=b[i]
                    if a[y]=='SetMovingSpeed':
                        chrmgrm=b[i]
                    if a[y]=='LogBox':
                        dbgm=b[i]
                    if a[y]=='GetMainCharacterIndex':
                        playerm=b[i]
                    if a[y]=='GetNameByVID':
                        chrm=b[i]
                    if a[y]=='SendShopEndPacket':
                        netm=b[i]
                    if a[y]=='DIK_UP':
                        appm=b[i]
                    if a[y]=='SelectItem':
                        itemm=b[i]
                    if a[y]=='Button':
                        uim=b[i]
                    if a[y]=='mouseController':
                        mouseModulem=b[i]
                    if a[y]=='GetAtlasSize':
                        miniMapm=b[i]
                    if a[y]=='GetMousePosition':
                        wndMgrm=b[i]
                    if a[y]=='GameWindow':
                        gamem=b[i]
                    if a[y]=='GetAvailableMemory':
                        grpm=b[i]
                    if a[y]=='InputDialog':
                        uiCommonm=b[i]
                    if a[y]=='AtlasWindow':
                        uiminimapm=b[i]
                    if a[y]=='BeginEnvironment':
                        backgroundm=b[i]
                    if a[y]=='LoadNonPlayerData':
                        nonplayerm=b[i]
                    if a[y]=='SetPosition':
                        effectm=b[i]
                    if a[y]=='GetQuestIndex':
                        questm=b[i]
                    if a[y]=='GetGuildLevel':
                        guildm=b[i]
huj='import '
try:
    exec (huj+nonplayerm+' as nonplayer')
except:
    exec (huj+nonplayerm+' as nonplayer')
try:
    exec (huj+backgroundm+' as background')
except:
    exec (huj+backgroundm+' as background')
try:
    exec (huj+uiCommonm+' as uiCommon')
except:
    exec (huj+uiCommonm+' as uiCommon')
try:
    exec (huj+uiminimapm+' as uiminimap')
except:
    exec (huj+uiminimapm+' as uiminimap')
try:
    exec (huj+dbgm+' as dbg')
except:
    exec (huj+dbgm+' as dbg')
try:
    exec (huj+gamem+' as game')
except:
    exec (huj+gamem+' as game')

try:
    exec (huj+playerm+' as player')
except:
    exec (huj+playerm+' as player')
try:
    exec (huj+netm+' as net')
except:
    exec (huj+netm+' as net')
try:
    exec (huj+appm+' as app')
except:
    exec (huj+appm+' as app')
try :
    exec(huj+itemm+' as item')
except:
    exec(huj+itemm+' as item')

try :
    exec(huj+uim+' as ui')
except:
    exec(huj+uim+' as ui')
    
try :
    
    exec(huj+mouseModulem+' as mouseModule')
except:
    exec(huj+mouseModulem+' as mouseModule')
try :
    exec(huj+miniMapm+' as miniMap')
except:
    exec(huj+miniMapm+' as miniMap')
try :
    exec(huj+wndMgrm+' as wndMgr')
except:
    exec(huj+wndMgrm+' as wndMgr')


try :
    exec(huj+chatm+' as chat')
except:
    exec(huj+chatm+' as chat')
try :
    exec(huj+localem+' as locale')
except:
    exec(huj+localem+' as locale')
try :
    exec(huj+localeinfom+' as localeinfo')
except:
    exec(huj+localeinfom+' as localeinfo')
try :
    exec(huj+netm+' as net')
except:
    exec(huj+netm+' as net')

try :
    exec(huj+skillm+' as skill')
except:
    exec(huj+skillm+' as skill')

try :
    exec (huj+chrm+' as chr')
except:
    exec (huj+chrm+' as chr')
try :
    exec (huj+chrmgrm+' as chrmgr')
except:
    exec (huj+chrmgrm+' as chrmgr')
try :
    exec (huj+sndm+' as snd')
except:
    exec (huj+sndm+' as snd')
try :
    exec (huj+grpm+' as grp')
except:
    exec (huj+grpm+' as grp')


try :
    exec (huj+shopm+' as shop')
except:
    exec (huj+shopm+' as shop')
try :
    exec (huj+textTailm+' as textTail')
except:
    exec (huj+textTailm+' as textTail')
try :
    import uiToolTip
    from uitooltip import ItemToolTip
except:
    pass

try :
    exec (huj+systemSettingm+' as systemSetting')
except:
    exec (huj+systemSettingm+' as systemSetting')
try :
    exec (huj+constInfom+' as constInfo')
except:
    exec (huj+constInfom+' as constInfo')
try :
    exec (huj+effectm+' as effect')
except:
    exec (huj+effectm+' as effect')
try :
    exec (huj+questm+' as quest')
except:
    exec (huj+questm+' as quest')
try :
    exec (huj+guildm+' as guild')
except:
    exec (huj+guildm+' as guild')
try :
    exec (huj+imem+' as ime')
except:
    exec (huj+imem+' as ime')
try:
    import pack
except:
    pass
from m2kmod.Modules.pyDetour import DetourFunction, DetourClass

	
def GetCurrentText(self):
	return self.textLine.GetText()
	
def OnSelectItem(self, index, name):
	self.SetCurrentItem(name)
	self.CloseListBox()
	
def GetSelectedIndex(self):
	return self.listBox.GetSelectedItem()
	
def HookedQuestWindow(data):
	pass
	

	
	
def PartyButton(self):
	dbg.LogBox("test")
	self.isShowStateButton = TRUE

	(x, y) = self.GetGlobalPosition()
	xPos = x + 110

	skillLevel = self.__GetPartySkillLevel()

	## Tanker
	if skillLevel >= 10:
		self.__AppendStateButton(xPos, y, player.PARTY_STATE_ATTACKER)
		xPos += 23

	## Attacker
	if skillLevel >= 20:
		self.__AppendStateButton(xPos, y, player.PARTY_STATE_BERSERKER)
		xPos += 23

	## Tanker
	if skillLevel >= 20:
		self.__AppendStateButton(xPos, y, player.PARTY_STATE_TANKER)
		xPos += 23

	# Buffer
	if skillLevel >= 25:
		self.__AppendStateButton(xPos, y, player.PARTY_STATE_BUFFER)
		xPos += 23

	## Skill Master
	if skillLevel >= 35:
		self.__AppendStateButton(xPos, y, player.PARTY_STATE_SKILL_MASTER)
		xPos += 23

	## Defender
	if skillLevel >= 40:
		self.__AppendStateButton(xPos, y, player.PARTY_STATE_DEFENDER)
		xPos += 23

	## Warp
	if skillLevel >= 35:
		if self.stateButtonDict.has_key(self.MEMBER_BUTTON_WARP):
			button = self.stateButtonDict[self.MEMBER_BUTTON_WARP]
			button.SetPosition(xPos, y)
			button.Show()
			xPos += 23

	## Expel
	if self.stateButtonDict.has_key(self.MEMBER_BUTTON_EXPEL):
		button = self.stateButtonDict[self.MEMBER_BUTTON_EXPEL]
		button.SetPosition(xPos, y)
		button.Show()
		xPos += 23
		

		
		
detour_questwindow = DetourFunction(game.GameWindow.OpenQuestWindow, HookedQuestWindow)

def SetComboHook():
	ui.ComboBox.GetCurrentText = GetCurrentText
	ui.ComboBox.GetSelectedIndex = GetSelectedIndex
	ui.ComboBox.OnSelectItem = OnSelectItem	
	
def SetQuestHook(arg):
	if arg:
		detour_questwindow.attach()
	else:
		detour_questwindow.detach()
			
def SetPartyWarpEnable():
	#oldPartyMemberInfoBoard = uiParty.PartyMemberInfoBoard
	#uiParty.PartyMemberInfoBoard = PartyMemberInfoBoard
	#uiParty.PartyMemberInfoBoard.__ShowStateButton = PartyButton
	dbg.LogBox("test")