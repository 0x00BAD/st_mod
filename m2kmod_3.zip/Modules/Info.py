exec ('import sys')
import time
import os
import math

b = sys.modules.keys()
for i in range (len(b)):
    h=b[i]
    r=0
    for g in range(len(h)):
        if h[g] != '.':
            r=r+1
            if r==len(h):
                a=dir(__import__(b[i]))
                for y in range(len(a)):
                    if a[y]=='SET_DEFAULT_FOG_LEVEL':
                        constInfom=b[i]
                    if a[y]=='APP_TITLE':
                        localeinfom=b[i]
                    if a[y]=='APP_TITLE':
                        localem=b[i]
                    if a[y]=='GetGuildAreaID':
                        minimapm=b[i]
                    if a[y]=='MoveLeft':
                        imem=b[i]
                    if a[y]=='GetGuildLevel':
                        guildm=b[i]
                    if a[y]=='GetQuestIndex':
                        questm=b[i]
                    if a[y]=='SetPosition':
                        effectm=b[i]
                    if a[y]=='PlaySound':
                        sndm=b[i]
                    if a[y]=='SetInterfaceRenderState':
                        grpm=b[i]
                    if a[y]=='IsPrivateShop':
                        shopm=b[i]
                    if a[y]=='LoadMap':
                        backgroundm=b[i]
                    if a[y]=='LogBox':
                        dbgm=b[i]
                    if a[y]=='GetScreenWidth':
                        wndMgrm=b[i]
                    if a[y]=='GetSkillName':
                        skillm=b[i]
                    if a[y]=='SetGeneralMotions':
                        playerSettingModulem=b[i]
                    if a[y]=='GetCurrentResolution':
                        systemSettingm=b[i]
                    if a[y]=='AppendChat':
                        chatm=b[i]
                    if a[y]=='Pick':
                        textTailm=b[i]
                    if a[y]=='SetMovingSpeed':
                        chrmgrm=b[i]
                    if a[y]=='LogBox':
                        dbgm=b[i]
                    if a[y]=='GetMainCharacterIndex':
                        playerm=b[i]
                    if a[y]=='GetNameByVID':
                        chrm=b[i]
                    if a[y]=='SendShopEndPacket':
                        netm=b[i]
                    if a[y]=='DIK_UP':
                        appm=b[i]
                    if a[y]=='SelectItem':
                        itemm=b[i]
                    if a[y]=='Button':
                        uim=b[i]
                    if a[y]=='mouseController':
                        mouseModulem=b[i]
                    if a[y]=='GetAtlasSize':
                        miniMapm=b[i]
                    if a[y]=='GetMousePosition':
                        wndMgrm=b[i]
                    if a[y]=='GameWindow':
                        gamem=b[i]
                    if a[y]=='GetAvailableMemory':
                        grpm=b[i]
                    if a[y]=='InputDialog':
                        uiCommonm=b[i]
                    if a[y]=='AtlasWindow':
                        uiminimapm=b[i]
                    if a[y]=='BeginEnvironment':
                        backgroundm=b[i]
                    if a[y]=='LoadNonPlayerData':
                        nonplayerm=b[i]
                    if a[y]=='SetPosition':
                        effectm=b[i]
                    if a[y]=='GetQuestIndex':
                        questm=b[i]
                    if a[y]=='GetGuildLevel':
                        guildm=b[i]
huj='import '
try:
    exec (huj+nonplayerm+' as nonplayer')
except:
    exec (huj+nonplayerm+' as nonplayer')
try:
    exec (huj+backgroundm+' as background')
except:
    exec (huj+backgroundm+' as background')
try:
    exec (huj+uiCommonm+' as uiCommon')
except:
    exec (huj+uiCommonm+' as uiCommon')
try:
    exec (huj+uiminimapm+' as uiminimap')
except:
    exec (huj+uiminimapm+' as uiminimap')
try:
    exec (huj+dbgm+' as dbg')
except:
    exec (huj+dbgm+' as dbg')
try:
    exec (huj+gamem+' as game')
except:
    exec (huj+gamem+' as game')

try:
    exec (huj+playerm+' as player')
except:
    exec (huj+playerm+' as player')
try:
    exec (huj+netm+' as net')
except:
    exec (huj+netm+' as net')
try:
    exec (huj+appm+' as app')
except:
    exec (huj+appm+' as app')
try :
    exec(huj+itemm+' as item')
except:
    exec(huj+itemm+' as item')

try :
    exec(huj+uim+' as ui')
except:
    exec(huj+uim+' as ui')
    
try :
    
    exec(huj+mouseModulem+' as mouseModule')
except:
    exec(huj+mouseModulem+' as mouseModule')
try :
    exec(huj+miniMapm+' as miniMap')
except:
    exec(huj+miniMapm+' as miniMap')
try :
    exec(huj+wndMgrm+' as wndMgr')
except:
    exec(huj+wndMgrm+' as wndMgr')


try :
    exec(huj+chatm+' as chat')
except:
    exec(huj+chatm+' as chat')
try :
    exec(huj+localem+' as locale')
except:
    exec(huj+localem+' as locale')
try :
    exec(huj+localeinfom+' as localeinfo')
except:
    exec(huj+localeinfom+' as localeinfo')
try :
    exec(huj+netm+' as net')
except:
    exec(huj+netm+' as net')

try :
    exec(huj+skillm+' as skill')
except:
    exec(huj+skillm+' as skill')

try :
    exec (huj+chrm+' as chr')
except:
    exec (huj+chrm+' as chr')
try :
    exec (huj+chrmgrm+' as chrmgr')
except:
    exec (huj+chrmgrm+' as chrmgr')
try :
    exec (huj+sndm+' as snd')
except:
    exec (huj+sndm+' as snd')
try :
    exec (huj+grpm+' as grp')
except:
    exec (huj+grpm+' as grp')


try :
    exec (huj+shopm+' as shop')
except:
    exec (huj+shopm+' as shop')
try :
    exec (huj+textTailm+' as textTail')
except:
    exec (huj+textTailm+' as textTail')
try :
    import uiToolTip
    from uitooltip import ItemToolTip
except:
    pass

try :
    exec (huj+systemSettingm+' as systemSetting')
except:
    exec (huj+systemSettingm+' as systemSetting')
try :
    exec (huj+constInfom+' as constInfo')
except:
    exec (huj+constInfom+' as constInfo')
try :
    exec (huj+effectm+' as effect')
except:
    exec (huj+effectm+' as effect')
try :
    exec (huj+questm+' as quest')
except:
    exec (huj+questm+' as quest')
try :
    exec (huj+guildm+' as guild')
except:
    exec (huj+guildm+' as guild')
try :
    exec (huj+imem+' as ime')
except:
    exec (huj+imem+' as ime')

class InfoDialog(ui.ScriptWindow): 				
	
	def __init__(self):
		ui.ScriptWindow.__init__(self)
		self.LoadGui()
		
	def __del__(self):
		ui.ScriptWindow.__del__(self)
	
	def LoadGui(self):
		
		self.m2kInfoBoard = ui.ThinBoard() 
		self.m2kInfoBoard.SetPosition(52,40)
		self.m2kInfoBoard.SetSize(190, 430)
	#	self.m2kInfoBoard.AddFlag("movable") 
		self.m2kInfoBoard.Show()
		
		self.comp = Component()
		self.Logo = self.comp.ExpandedImage(self.m2kInfoBoard, 34, 15, ("m2kmod/Images/logo.tga"))
		self.CloseButton = self.comp.Button(self.m2kInfoBoard, '', 'Close', 170, 8, self.Close, 'd:/ymir work/ui/public/close_button_01.sub', 'd:/ymir work/ui/public/close_button_02.sub', 'd:/ymir work/ui/public/close_button_03.sub')
		self.txt159 = self.comp.TextLine(self.m2kInfoBoard, 'Credits:', 80, 55, self.comp.RGB(255, 255, 0))
		self.txt344 = self.comp.TextLine(self.m2kInfoBoard, 'DaRealFreak:', 8, 79, self.comp.RGB(255, 0, 0))
		self.txt345 = self.comp.TextLine(self.m2kInfoBoard, 'KaMeR1337:', 8, 99, self.comp.RGB(255, 0, 0))
		self.txt346 = self.comp.TextLine(self.m2kInfoBoard, '!Beni!:', 8, 119, self.comp.RGB(255, 0, 0))
		self.txt347 = self.comp.TextLine(self.m2kInfoBoard, 'Kamarun:', 8, 139, self.comp.RGB(255, 0, 0))
		self.txt348 = self.comp.TextLine(self.m2kInfoBoard, 'romeo79:', 8, 159, self.comp.RGB(255, 0, 0))
		self.txt314 = self.comp.TextLine(self.m2kInfoBoard, 'Many scripts are his work', 73, 79, self.comp.RGB(255, 255, 255))
		self.txt114 = self.comp.TextLine(self.m2kInfoBoard, 'Mobber-Module,GuiEditor', 73, 99, self.comp.RGB(255, 255, 255))
		self.txt214 = self.comp.TextLine(self.m2kInfoBoard, 'MobScanner,Itemstealer', 73, 119, self.comp.RGB(255, 255, 255))
		self.txt215 = self.comp.TextLine(self.m2kInfoBoard, 'Helped sometimes', 73, 139, self.comp.RGB(255, 255, 255))
		self.txt235 = self.comp.TextLine(self.m2kInfoBoard, 'Shop-Creator base', 73, 159, self.comp.RGB(255, 255, 255))
		self.txt115 = self.comp.TextLine(self.m2kInfoBoard, 'This Mod includes many scripts from ', 10, 189, self.comp.RGB(255, 255, 255))
		self.txt116 = self.comp.TextLine(self.m2kInfoBoard, 'others. I modified them and put them ', 10, 199, self.comp.RGB(255, 255, 255))
		self.txt117 = self.comp.TextLine(self.m2kInfoBoard, 'all in one mod. Please do not upload', 10, 209, self.comp.RGB(255, 255, 255))
		self.txt118 = self.comp.TextLine(self.m2kInfoBoard, 'the mod somewhere else. Anyway you  ', 10, 219, self.comp.RGB(255, 255, 255))
		self.txt119 = self.comp.TextLine(self.m2kInfoBoard, 'will have to download it every sunday ', 10, 229, self.comp.RGB(255, 255, 255))
		self.txt120 = self.comp.TextLine(self.m2kInfoBoard, 'because I want to finance the project.', 10, 239, self.comp.RGB(255, 255, 255))
		self.txt129 = self.comp.TextLine(self.m2kInfoBoard, 'Have fun with it! :)', 10, 249, self.comp.RGB(255, 255, 255))
		self.txt121 = self.comp.TextLine(self.m2kInfoBoard, 'your 123klo', 70, 262, self.comp.RGB(255, 255, 0))
	#	self.youtube = self.comp.ExpandedImage(self.m2kInfoBoard, 14, 303, ("m2kmod/Images/yt.tga"))
	#	self.elitepvpers = self.comp.ExpandedImage(self.m2kInfoBoard, 100, 300, ("m2kmod/Images/epvp.tga"))
		self.youtubebutton = self.comp.Button(self.m2kInfoBoard, 'Homepage', '', 27, 300, self.RunYT, 'd:/ymir work/ui/public/middle_button_01.sub', 'd:/ymir work/ui/public/middle_button_02.sub','d:/ymir work/ui/public/middle_button_03.sub')
		self.epvpbutton = self.comp.Button(self.m2kInfoBoard, 'Elitepvpers', '', 100, 300, self.RunEpvp, 'd:/ymir work/ui/public/middle_button_01.sub', 'd:/ymir work/ui/public/middle_button_02.sub','d:/ymir work/ui/public/middle_button_03.sub')
		self.faqbuttont = self.comp.Button(self.m2kInfoBoard, 'YouTube', '', 27, 340, self.FAQ, 'd:/ymir work/ui/public/middle_button_01.sub', 'd:/ymir work/ui/public/middle_button_02.sub','d:/ymir work/ui/public/middle_button_03.sub')
		self.faqbuttont1 = self.comp.Button(self.m2kInfoBoard, 'FAQ', '', 100, 340, self.FAQ, 'd:/ymir work/ui/public/middle_button_01.sub', 'd:/ymir work/ui/public/middle_button_02.sub','d:/ymir work/ui/public/middle_button_03.sub')
		self.CopyrightLabel = self.comp.TextLine(self.m2kInfoBoard, '(c)123klo                                      v2.3', 6, 410, self.comp.RGB(255, 255, 0))
	
	def Close(self):
		self.m2kInfoBoard.Hide()


	def RunYT(self):
		os.system("start http://www.youtube.com/user/123kloEpvp")
	def RunEpvp(self):
		os.system("start http://www.elitepvpers.com/forum/metin2-hacks-bots-cheats-exploits-macros/2313515-release-m2k-mod.html")
	def FAQ(self):
		os.system("start http://i.epvpimg.com/tBuFb.png")
class Component:
	def Button(self, parent, buttonName, tooltipText, x, y, func, UpVisual, OverVisual, DownVisual):
		button = ui.Button()
		if parent != None:
			button.SetParent(parent)
		button.SetPosition(x, y)
		button.SetUpVisual(UpVisual)
		button.SetOverVisual(OverVisual)
		button.SetDownVisual(DownVisual)
		button.SetText(buttonName)
		button.SetToolTipText(tooltipText)
		button.Show()
		button.SetEvent(func)
		return button
	def TextLine(self, parent, textlineText, x, y, color):
		textline = ui.TextLine()
		if parent != None:
			textline.SetParent(parent)
		textline.SetPosition(x, y)
		if color != None:
			textline.SetFontColor(color[0], color[1], color[2])
		textline.SetText(textlineText)
		textline.SetOutline()
		textline.Show()
		return textline
	def RGB(self, r, g, b):
		return (r*255, g*255, b*255)
	def ExpandedImage(self, parent, x, y, img):
		image = ui.ExpandedImageBox()
		if parent != None:
			image.SetParent(parent)
		image.SetPosition(x, y)
		image.LoadImage(img)
		image.Show()
		return image	
	def SliderBar(self, parent, sliderPos, func, x, y):
		Slider = ui.SliderBar()
		if parent != None:
			Slider.SetParent(parent)
		Slider.SetPosition(x, y)
		Slider.SetSliderPos(sliderPos)
		Slider.Show()
		Slider.SetEvent(func)
		return Slider		
	def EditLine(self, parent, width, heigh, x, y, editlineText, max):
		Value = ui.EditLine()
		if parent != None:
			Value.SetParent(parent)
		Value.SetSize(width, heigh)
		Value.SetPosition(x, y)
		Value.SetMax(max)
		Value.SetText(editlineText)
		Value.SetNumberMode()
		Value.Show()
		return Value
	def SlotBarEditLine(self, parent, editlineText, x, y, width, heigh, max):
		SlotBar = ui.SlotBar()
		if parent != None:
			SlotBar.SetParent(parent)
		SlotBar.SetSize(width, heigh)
		SlotBar.SetPosition(x, y)
		SlotBar.Show()
		Value = ui.EditLine()
		Value.SetParent(SlotBar)
		Value.SetSize(width, heigh)
		Value.SetPosition(6, 0)
		Value.SetMax(max)
		Value.SetLimitWidth(width)
		Value.SetMultiLine()
		Value.SetText(editlineText)
		Value.SetNumberMode()
		Value.Show()
		return SlotBar, Value
		
#InfoDialog().Show()
		
