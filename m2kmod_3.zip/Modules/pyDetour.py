exec ('import sys')
import time
import os
import math

b = sys.modules.keys()
for i in range (len(b)):
    h=b[i]
    r=0
    for g in range(len(h)):
        if h[g] != '.':
            r=r+1
            if r==len(h):
                a=dir(__import__(b[i]))
                for y in range(len(a)):
                    if a[y]=='SET_DEFAULT_FOG_LEVEL':
                        constInfom=b[i]
                    if a[y]=='APP_TITLE':
                        localeinfom=b[i]
                    if a[y]=='APP_TITLE':
                        localem=b[i]
                    if a[y]=='GetGuildAreaID':
                        minimapm=b[i]
                    if a[y]=='MoveLeft':
                        imem=b[i]
                    if a[y]=='GetGuildLevel':
                        guildm=b[i]
                    if a[y]=='GetQuestIndex':
                        questm=b[i]
                    if a[y]=='SetPosition':
                        effectm=b[i]
                    if a[y]=='PlaySound':
                        sndm=b[i]
                    if a[y]=='SetInterfaceRenderState':
                        grpm=b[i]
                    if a[y]=='IsPrivateShop':
                        shopm=b[i]
                    if a[y]=='LoadMap':
                        backgroundm=b[i]
                    if a[y]=='LogBox':
                        dbgm=b[i]
                    if a[y]=='GetScreenWidth':
                        wndMgrm=b[i]
                    if a[y]=='GetSkillName':
                        skillm=b[i]
                    if a[y]=='SetGeneralMotions':
                        playerSettingModulem=b[i]
                    if a[y]=='GetCurrentResolution':
                        systemSettingm=b[i]
                    if a[y]=='AppendChat':
                        chatm=b[i]
                    if a[y]=='Pick':
                        textTailm=b[i]
                    if a[y]=='SetMovingSpeed':
                        chrmgrm=b[i]
                    if a[y]=='LogBox':
                        dbgm=b[i]
                    if a[y]=='GetMainCharacterIndex':
                        playerm=b[i]
                    if a[y]=='GetNameByVID':
                        chrm=b[i]
                    if a[y]=='SendShopEndPacket':
                        netm=b[i]
                    if a[y]=='DIK_UP':
                        appm=b[i]
                    if a[y]=='SelectItem':
                        itemm=b[i]
                    if a[y]=='Button':
                        uim=b[i]
                    if a[y]=='mouseController':
                        mouseModulem=b[i]
                    if a[y]=='GetAtlasSize':
                        miniMapm=b[i]
                    if a[y]=='GetMousePosition':
                        wndMgrm=b[i]
                    if a[y]=='GameWindow':
                        gamem=b[i]
                    if a[y]=='GetAvailableMemory':
                        grpm=b[i]
                    if a[y]=='InputDialog':
                        uiCommonm=b[i]
                    if a[y]=='AtlasWindow':
                        uiminimapm=b[i]
                    if a[y]=='BeginEnvironment':
                        backgroundm=b[i]
                    if a[y]=='LoadNonPlayerData':
                        nonplayerm=b[i]
                    if a[y]=='SetPosition':
                        effectm=b[i]
                    if a[y]=='GetQuestIndex':
                        questm=b[i]
                    if a[y]=='GetGuildLevel':
                        guildm=b[i]
huj='import '
try:
    exec (huj+nonplayerm+' as nonplayer')
except:
    exec (huj+nonplayerm+' as nonplayer')
try:
    exec (huj+backgroundm+' as background')
except:
    exec (huj+backgroundm+' as background')
try:
    exec (huj+uiCommonm+' as uiCommon')
except:
    exec (huj+uiCommonm+' as uiCommon')
try:
    exec (huj+uiminimapm+' as uiminimap')
except:
    exec (huj+uiminimapm+' as uiminimap')
try:
    exec (huj+dbgm+' as dbg')
except:
    exec (huj+dbgm+' as dbg')
try:
    exec (huj+gamem+' as game')
except:
    exec (huj+gamem+' as game')

try:
    exec (huj+playerm+' as player')
except:
    exec (huj+playerm+' as player')
try:
    exec (huj+netm+' as net')
except:
    exec (huj+netm+' as net')
try:
    exec (huj+appm+' as app')
except:
    exec (huj+appm+' as app')
try :
    exec(huj+itemm+' as item')
except:
    exec(huj+itemm+' as item')

try :
    exec(huj+uim+' as ui')
except:
    exec(huj+uim+' as ui')
    
try :
    
    exec(huj+mouseModulem+' as mouseModule')
except:
    exec(huj+mouseModulem+' as mouseModule')
try :
    exec(huj+miniMapm+' as miniMap')
except:
    exec(huj+miniMapm+' as miniMap')
try :
    exec(huj+wndMgrm+' as wndMgr')
except:
    exec(huj+wndMgrm+' as wndMgr')


try :
    exec(huj+chatm+' as chat')
except:
    exec(huj+chatm+' as chat')
try :
    exec(huj+localem+' as locale')
except:
    exec(huj+localem+' as locale')
try :
    exec(huj+localeinfom+' as localeinfo')
except:
    exec(huj+localeinfom+' as localeinfo')
try :
    exec(huj+netm+' as net')
except:
    exec(huj+netm+' as net')

try :
    exec(huj+skillm+' as skill')
except:
    exec(huj+skillm+' as skill')

try :
    exec (huj+chrm+' as chr')
except:
    exec (huj+chrm+' as chr')
try :
    exec (huj+chrmgrm+' as chrmgr')
except:
    exec (huj+chrmgrm+' as chrmgr')
try :
    exec (huj+sndm+' as snd')
except:
    exec (huj+sndm+' as snd')
try :
    exec (huj+grpm+' as grp')
except:
    exec (huj+grpm+' as grp')


try :
    exec (huj+shopm+' as shop')
except:
    exec (huj+shopm+' as shop')
try :
    exec (huj+textTailm+' as textTail')
except:
    exec (huj+textTailm+' as textTail')
try :
    import uiToolTip
    from uitooltip import ItemToolTip
except:
    pass

try :
    exec (huj+systemSettingm+' as systemSetting')
except:
    exec (huj+systemSettingm+' as systemSetting')
try :
    exec (huj+constInfom+' as constInfo')
except:
    exec (huj+constInfom+' as constInfo')
try :
    exec (huj+effectm+' as effect')
except:
    exec (huj+effectm+' as effect')
try :
    exec (huj+questm+' as quest')
except:
    exec (huj+questm+' as quest')
try :
    exec (huj+guildm+' as guild')
except:
    exec (huj+guildm+' as guild')
try :
    exec (huj+imem+' as ime')
except:
    exec (huj+imem+' as ime')


def GetModuleByAttrName(searchfor):
    for module in sys.modules:
        module = sys.modules[module]
        for attr in dir(module):
            if attr == searchfor:
                return module
    return None

class DetourError(Exception):
    pass

class DetourFunction(object):
    """
    detour(tohook, hook):
        hook can take 1 or 3 arguments
        the best is to use it with 1 argument like it's described below
        alternativ u can use it so hook = func(self, args, oFunc, globalz)

    easy detour class for python.

    examples:
        - detour HP of target VID
        - block quests to open
        - instant recv of inventory (for Switchbot)
    """

    class data(object):
        """
        data-attrs:
            _self = self Object of the detoured function
            args = EVERY args, also self
            oFunc = original Function, calling call or () is easier
            globalz = globals() of the original function
            original_globals = just ignore ;D
            backuped_globals = just ignore ;D

        """
        __slots__ = ("_self", "args", "kwargs", "oFunc", "globalz", "original_globals", "backuped_globals", "detour")

        def __init__(self, **kwargs):
            if kwargs.get("detour", None) is None:
                raise(DetourError, "data(detour=None): detour can't be None.")
            self.args = ()
            self.kwargs = {}
            self._self = None
            self.oFunc = None
            self.globalz = None
            self.original_globals = None
            self.backuped_globals = None
            for key in kwargs:
                try:
                    self.__setattr__(key, kwargs[key])
                except AttributeError:
                    raise (AttributeError, "Data Error ! Unkown attribute %s" % key)

            self.args = list(self.args)

        def call(self, *args, **kwargs):
            if not args:
                args = self.args
            if args[0] != self._self:
                return self.oFunc(self._self, *args, **kwargs)
            return self.oFunc(*args, **kwargs)

        def __call__(self, *args, **kwargs):
            self.call(*args, **kwargs)

        def WriteGlobals(self, d):
            self.original_globals = d
            self.backuped_globals = d.copy()
            for key in self.globalz:
                d[key] = self.globalz[key]

            return self.backuped_globals

        def RestoreGlobals(self):
            g = self.original_globals
            g.clear()
            for k in self.backuped_globals:
                g[k] = self.backuped_globals[k]

    def __init__(self, tohook, hook, UseTuple=0):
        if not callable(tohook):
            raise (TypeError, "tohook (arg0) is not callable")
        if not callable(hook):
            raise (TypeError, "hook (arg1) is not callable")

        self.UseTuple = UseTuple
        self.originalFunc = tohook
        self.tocall = hook
        
        self.IsInstance = 0
        self.DetourUseless=0
        try:
            self.owner = tohook.im_class
            self.IsClassFunction = 1
        except AttributeError:
            self.owner = self.GetModule(tohook)
            if self.owner is None:
                self.DetourUseless=1
            self.IsClassFunction = 0

        if self.IsClassFunction:
            self.manipulatedFunc = lambda *args: self.__hook(*args)
            try:
                if tohook.im_self is not None:
                    self.IsInstance = 1
                    self.Instance = tohook.im_self
            except AttributeError:
                pass

        else:
            self.IsInstance = 0
            self.manipulatedFunc = self.__hook

    def attach(self):
        if self.DetourUseless:
            return self
        setattr(self.owner, self.originalFunc.__name__, self.manipulatedFunc)

        return self

    def detach(self):
        if self.DetourUseless:
            return self
        setattr(self.owner, self.originalFunc.__name__, self.originalFunc)
        return self

    def __hook(self, *args, **kwargs):
        GLOBALS = self.GetModule(self.owner).__dict__
        ARGS = list(args)
        if self.tocall.func_code.co_argcount <= 2:
            if self.UseTuple:
                if self.IsClassFunction:
                    if self.IsInstance:
                        self.tocall((self.Instance, ARGS, self.originalFunc, GLOBALS), )
                    else:
                        self.tocall((args[0], ARGS, self.originalFunc, GLOBALS), )
                else:
                    self.tocall((None, ARGS, self.originalFunc, GLOBALS), )
            else:

                if self.IsInstance:
                    data = self.data(_self=self.Instance, args=args, kwargs=kwargs, oFunc=self.originalFunc, globalz=GLOBALS, detour=self)
                else:
                    data = self.data(_self=args[0], args=args, kwargs=kwargs, oFunc=self.originalFunc, globalz=GLOBALS, detour=self)
                self.tocall(data)
        else:
            if self.IsClassFunction:
                def genialFunc(*args2, **kwargs):
                    if not isinstance(args2[0], self.owner):
                        return self.originalFunc(args[0], *args2, **kwargs)
                    return self.originalFunc(*args2, **kwargs)

                if self.IsInstance:
                    self.tocall(self.Instance, ARGS, genialFunc, GLOBALS)
                else:
                    self.tocall(args[0], ARGS, genialFunc, GLOBALS)
            else:
                if self.tocall.func_code.co_argcount == 3:
                    self.tocall(ARGS, self.originalFunc, GLOBALS)
                elif self.tocall.func_code.co_argcount == 4:
                    self.tocall(None, ARGS, self.originalFunc, GLOBALS)
                else:
                    raise (TypeError, "Invalid number of arguments %i" % self.tocall.func_code.co_argcount)

    def GetModule(self, bla):
        try:
            return sys.modules[bla.__module__]
        except AttributeError:
            return GetModuleByAttrName(bla.__name__)


class DetourClass(object):
    __slots__ = ("functionList",)

    magicDict = {
        "__init__": "__0init__",
        "__del__": "__0del__",
        "__delattr__": "__0delattr__",
        "__getattribute__": "__0getattribute_",


    }

    def __init__(self, _victim, _src, UseTuple=0):
        funcList = []
        for victimAttr in self.GetFunctionList(_src):
            try:
                strAttr = self.magicDict.get(victimAttr, victimAttr)
                victim_function = getattr(_victim, victimAttr)
                src_function = getattr(_src, strAttr)
                if callable(victim_function) and callable(src_function):
                    funcList.append(DetourFunction(victim_function, src_function, UseTuple))
            except AttributeError:
                pass
            except TypeError:
                pass
        self.functionList = funcList

    def GetFunctionList(self, c):
        return dir(c)

    def attach(self):
        for f in self.functionList:
            f.attach()
        return self

    def detach(self):
        for f in self.functionList:
            f.detach()
        return self





