exec ('import sys')
import time
import os
import math

b = sys.modules.keys()
for i in range (len(b)):
    h=b[i]
    r=0
    for g in range(len(h)):
        if h[g] != '.':
            r=r+1
            if r==len(h):
                a=dir(__import__(b[i]))
                for y in range(len(a)):
                    if a[y]=='SET_DEFAULT_FOG_LEVEL':
                        constInfom=b[i]
                    if a[y]=='APP_TITLE':
                        localeinfom=b[i]
                    if a[y]=='APP_TITLE':
                        localem=b[i]
                    if a[y]=='GetGuildAreaID':
                        minimapm=b[i]
                    if a[y]=='MoveLeft':
                        imem=b[i]
                    if a[y]=='GetGuildLevel':
                        guildm=b[i]
                    if a[y]=='GetQuestIndex':
                        questm=b[i]
                    if a[y]=='SetPosition':
                        effectm=b[i]
                    if a[y]=='PlaySound':
                        sndm=b[i]
                    if a[y]=='SetInterfaceRenderState':
                        grpm=b[i]
                    if a[y]=='IsPrivateShop':
                        shopm=b[i]
                    if a[y]=='LoadMap':
                        backgroundm=b[i]
                    if a[y]=='LogBox':
                        dbgm=b[i]
                    if a[y]=='GetScreenWidth':
                        wndMgrm=b[i]
                    if a[y]=='GetSkillName':
                        skillm=b[i]
                    if a[y]=='SetGeneralMotions':
                        playerSettingModulem=b[i]
                    if a[y]=='GetCurrentResolution':
                        systemSettingm=b[i]
                    if a[y]=='AppendChat':
                        chatm=b[i]
                    if a[y]=='Pick':
                        textTailm=b[i]
                    if a[y]=='SetMovingSpeed':
                        chrmgrm=b[i]
                    if a[y]=='LogBox':
                        dbgm=b[i]
                    if a[y]=='GetMainCharacterIndex':
                        playerm=b[i]
                    if a[y]=='GetNameByVID':
                        chrm=b[i]
                    if a[y]=='SendShopEndPacket':
                        netm=b[i]
                    if a[y]=='DIK_UP':
                        appm=b[i]
                    if a[y]=='SelectItem':
                        itemm=b[i]
                    if a[y]=='Button':
                        uim=b[i]
                    if a[y]=='mouseController':
                        mouseModulem=b[i]
                    if a[y]=='GetAtlasSize':
                        miniMapm=b[i]
                    if a[y]=='GetMousePosition':
                        wndMgrm=b[i]
                    if a[y]=='GameWindow':
                        gamem=b[i]
                    if a[y]=='GetAvailableMemory':
                        grpm=b[i]
                    if a[y]=='InputDialog':
                        uiCommonm=b[i]
                    if a[y]=='AtlasWindow':
                        uiminimapm=b[i]
                    if a[y]=='BeginEnvironment':
                        backgroundm=b[i]
                    if a[y]=='LoadNonPlayerData':
                        nonplayerm=b[i]
                    if a[y]=='SetPosition':
                        effectm=b[i]
                    if a[y]=='GetQuestIndex':
                        questm=b[i]
                    if a[y]=='GetGuildLevel':
                        guildm=b[i]
huj='import '
try:
    exec (huj+nonplayerm+' as nonplayer')
except:
    exec (huj+nonplayerm+' as nonplayer')
try:
    exec (huj+backgroundm+' as background')
except:
    exec (huj+backgroundm+' as background')
try:
    exec (huj+uiCommonm+' as uiCommon')
except:
    exec (huj+uiCommonm+' as uiCommon')
try:
    exec (huj+uiminimapm+' as uiminimap')
except:
    exec (huj+uiminimapm+' as uiminimap')
try:
    exec (huj+dbgm+' as dbg')
except:
    exec (huj+dbgm+' as dbg')
try:
    exec (huj+gamem+' as game')
except:
    exec (huj+gamem+' as game')

try:
    exec (huj+playerm+' as player')
except:
    exec (huj+playerm+' as player')
try:
    exec (huj+netm+' as net')
except:
    exec (huj+netm+' as net')
try:
    exec (huj+appm+' as app')
except:
    exec (huj+appm+' as app')
try :
    exec(huj+itemm+' as item')
except:
    exec(huj+itemm+' as item')

try :
    exec(huj+uim+' as ui')
except:
    exec(huj+uim+' as ui')
    
try :
    
    exec(huj+mouseModulem+' as mouseModule')
except:
    exec(huj+mouseModulem+' as mouseModule')
try :
    exec(huj+miniMapm+' as miniMap')
except:
    exec(huj+miniMapm+' as miniMap')
try :
    exec(huj+wndMgrm+' as wndMgr')
except:
    exec(huj+wndMgrm+' as wndMgr')


try :
    exec(huj+chatm+' as chat')
except:
    exec(huj+chatm+' as chat')
try :
    exec(huj+localem+' as locale')
except:
    exec(huj+localem+' as locale')
try :
    exec(huj+localeinfom+' as localeinfo')
except:
    exec(huj+localeinfom+' as localeinfo')
try :
    exec(huj+netm+' as net')
except:
    exec(huj+netm+' as net')

try :
    exec(huj+skillm+' as skill')
except:
    exec(huj+skillm+' as skill')

try :
    exec (huj+chrm+' as chr')
except:
    exec (huj+chrm+' as chr')
try :
    exec (huj+chrmgrm+' as chrmgr')
except:
    exec (huj+chrmgrm+' as chrmgr')
try :
    exec (huj+sndm+' as snd')
except:
    exec (huj+sndm+' as snd')
try :
    exec (huj+grpm+' as grp')
except:
    exec (huj+grpm+' as grp')


try :
    exec (huj+shopm+' as shop')
except:
    exec (huj+shopm+' as shop')
try :
    exec (huj+textTailm+' as textTail')
except:
    exec (huj+textTailm+' as textTail')
try :
    import uiToolTip
    from uitooltip import ItemToolTip
except:
    pass

try :
    exec (huj+systemSettingm+' as systemSetting')
except:
    exec (huj+systemSettingm+' as systemSetting')
try :
    exec (huj+constInfom+' as constInfo')
except:
    exec (huj+constInfom+' as constInfo')
try :
    exec (huj+effectm+' as effect')
except:
    exec (huj+effectm+' as effect')
try :
    exec (huj+questm+' as quest')
except:
    exec (huj+questm+' as quest')
try :
    exec (huj+guildm+' as guild')
except:
    exec (huj+guildm+' as guild')
try :
    exec (huj+imem+' as ime')
except:
    exec (huj+imem+' as ime')

import thread
from time import sleep,clock

class Teleport(object):
	def __init__(self,x=None,y=None,vid=None,loadnear=1):
		self.rdyY = 0
		self.rdyX = 0
		self.VidMode=0
		self.counter=0
		self.start=self.Start
		self.TarX,self.TarY,self.TarZ,self.vid,self.ln=0,0,0,0,0
		if x is None and y is None and vid is None and loadnear==1:
			pass
		else:
			self.SetMode(x,y,vid,loadnear)
		self.SendPosi = lambda bla=player.SetSingleDIKKeyState,key=app.DIK_LEFT, blax=chr.SetLoopMotion,val1=chr.MOTION_WAIT: bla(key, TRUE) == bla(key, FALSE) == blax(val1)
	def Start(self,owner=None):
		self.owner=owner
		self.isFinish = 0
		self.maxRange=1249#1649
		try:
			self.Mem.Hide()
		except:
			pass
		self.Set()
		#thread.start_new_thread(self.Set,())
	def SendPos(self):
		chr.SetLoopMotion(chr.MOTION_WAIT)
		player.SetSingleDIKKeyState(app.DIK_UP, TRUE)
		player.SetSingleDIKKeyState(app.DIK_UP, FALSE)
		chr.SetLoopMotion(chr.MOTION_WAIT)
		#if not self.VidMode:
		#	self.nomove.Deactiv()
	def LoadNear(self):
		chr.SetPixelPosition(self.TarX, self.TarY)
		chr.SetPixelPosition(self.TarX, self.TarY)
		player.SetSingleDIKKeyState(app.DIK_UP, TRUE)
		time=clock()#3
		while time+5>=clock():
			self.Upda()
		player.SetSingleDIKKeyState(app.DIK_UP, FALSE)
		chr.SetPixelPosition(int(self.TarX), int(self.TarY))
	def End(self):
		chr.SetPixelPosition(int(self.TarX), int(self.TarY))
		if self.ln!=0:
			self.LoadNear()
		else:
			player.SetSingleDIKKeyState(app.DIK_UP, FALSE)
	def Set(self):
		import math
		
		MAP = background.GetCurrentMapName()
		px,py = player.GetMainCharacterPosition()[:2]
		px,py = int(px),int(py)
		setPosition = chr.SetPixelPosition
		chr.SelectInstance(player.GetMainCharacterIndex())
		SendPosi = self.SendPosi
		TarY = int(self.TarY)
		TarX = int(self.TarX)
		maxRange=1765
		rdyX,rdyY=0,0
		while rdyX==0 or rdyY==0:
			if not rdyY:
				if not TarY-(maxRange+1) < py < TarY+(maxRange+1):
					if py < TarY:
						py+=(maxRange)
					elif py > TarY:
						py-=(maxRange)
				else:
					maxRange=2500
					rdyY=1
			if not rdyX:
				if not TarX-(maxRange+1) < px < TarX+(maxRange+1):
					if px < TarX:
						px+=(maxRange)
					elif px > TarX:
						px-=(maxRange)
				else:
					maxRange=2500
					rdyX=1
			# SetPosition Clientside
			setPosition(px, py)
			SendPosi() # SendPositionPacket
		setPosition(TarX, TarY)
		SendPosi()
		if self.owner: self.owner.TeleportState=1
	def SetMode(self,x=None,y=None,vid=None,loadnear=1):
		# ueberladenes begin
		if chr.HasInstance(x) and vid==None:
			vid=x
			x=None
		if vid and 0<=y<=1:
			loadnear=y
			y=None
		# ueberladenes end
		self.ln=loadnear
		if vid != None:
			self.vid = vid
			self.TarX,self.TarY,self.TarZ = [int(i) for i in chr.GetPixelPosition(vid)]
			return self.TarX,self.TarY,self.TarZ
		elif x != None and y != None:
			self.vid = None
			self.TarX,self.TarY = int(x),int(y)
			return self.TarX,self.TarY,1
	def tp2dest(self,vid):
		self.ln=0
		self.vid = vid
		self.VidMode=1
		try:
			if isinstance(vid,int):
				self.TarX,self.TarY,self.TarZ = [int(i) for i in chr.GetPixelPosition(vid)]
			elif isinstance(vid,tuple):
				self.TarX,self.TarY=vid
		except:
			return
		self.TarX+=50
		self.start()
