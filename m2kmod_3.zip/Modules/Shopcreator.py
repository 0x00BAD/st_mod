exec ('import sys')
import time
import os
import math

b = sys.modules.keys()
for i in range (len(b)):
    h=b[i]
    r=0
    for g in range(len(h)):
        if h[g] != '.':
            r=r+1
            if r==len(h):
                a=dir(__import__(b[i]))
                for y in range(len(a)):
                    if a[y]=='SET_DEFAULT_FOG_LEVEL':
                        constInfom=b[i]
                    if a[y]=='APP_TITLE':
                        localeinfom=b[i]
                    if a[y]=='APP_TITLE':
                        localem=b[i]
                    if a[y]=='GetGuildAreaID':
                        minimapm=b[i]
                    if a[y]=='MoveLeft':
                        imem=b[i]
                    if a[y]=='GetGuildLevel':
                        guildm=b[i]
                    if a[y]=='GetQuestIndex':
                        questm=b[i]
                    if a[y]=='SetPosition':
                        effectm=b[i]
                    if a[y]=='PlaySound':
                        sndm=b[i]
                    if a[y]=='SetInterfaceRenderState':
                        grpm=b[i]
                    if a[y]=='IsPrivateShop':
                        shopm=b[i]
                    if a[y]=='LoadMap':
                        backgroundm=b[i]
                    if a[y]=='LogBox':
                        dbgm=b[i]
                    if a[y]=='GetScreenWidth':
                        wndMgrm=b[i]
                    if a[y]=='GetSkillName':
                        skillm=b[i]
                    if a[y]=='SetGeneralMotions':
                        playerSettingModulem=b[i]
                    if a[y]=='GetCurrentResolution':
                        systemSettingm=b[i]
                    if a[y]=='AppendChat':
                        chatm=b[i]
                    if a[y]=='Pick':
                        textTailm=b[i]
                    if a[y]=='SetMovingSpeed':
                        chrmgrm=b[i]
                    if a[y]=='LogBox':
                        dbgm=b[i]
                    if a[y]=='GetMainCharacterIndex':
                        playerm=b[i]
                    if a[y]=='GetNameByVID':
                        chrm=b[i]
                    if a[y]=='SendShopEndPacket':
                        netm=b[i]
                    if a[y]=='DIK_UP':
                        appm=b[i]
                    if a[y]=='SelectItem':
                        itemm=b[i]
                    if a[y]=='Button':
                        uim=b[i]
                    if a[y]=='mouseController':
                        mouseModulem=b[i]
                    if a[y]=='GetAtlasSize':
                        miniMapm=b[i]
                    if a[y]=='GetMousePosition':
                        wndMgrm=b[i]
                    if a[y]=='GameWindow':
                        gamem=b[i]
                    if a[y]=='GetAvailableMemory':
                        grpm=b[i]
                    if a[y]=='InputDialog':
                        uiCommonm=b[i]
                    if a[y]=='AtlasWindow':
                        uiminimapm=b[i]
                    if a[y]=='BeginEnvironment':
                        backgroundm=b[i]
                    if a[y]=='LoadNonPlayerData':
                        nonplayerm=b[i]
                    if a[y]=='SetPosition':
                        effectm=b[i]
                    if a[y]=='GetQuestIndex':
                        questm=b[i]
                    if a[y]=='GetGuildLevel':
                        guildm=b[i]
huj='import '
try:
    exec (huj+nonplayerm+' as nonplayer')
except:
    exec (huj+nonplayerm+' as nonplayer')
try:
    exec (huj+backgroundm+' as background')
except:
    exec (huj+backgroundm+' as background')
try:
    exec (huj+uiCommonm+' as uiCommon')
except:
    exec (huj+uiCommonm+' as uiCommon')
try:
    exec (huj+uiminimapm+' as uiminimap')
except:
    exec (huj+uiminimapm+' as uiminimap')
try:
    exec (huj+dbgm+' as dbg')
except:
    exec (huj+dbgm+' as dbg')
try:
    exec (huj+gamem+' as game')
except:
    exec (huj+gamem+' as game')

try:
    exec (huj+playerm+' as player')
except:
    exec (huj+playerm+' as player')
try:
    exec (huj+netm+' as net')
except:
    exec (huj+netm+' as net')
try:
    exec (huj+appm+' as app')
except:
    exec (huj+appm+' as app')
try :
    exec(huj+itemm+' as item')
except:
    exec(huj+itemm+' as item')

try :
    exec(huj+uim+' as ui')
except:
    exec(huj+uim+' as ui')
    
try :
    
    exec(huj+mouseModulem+' as mouseModule')
except:
    exec(huj+mouseModulem+' as mouseModule')
try :
    exec(huj+miniMapm+' as miniMap')
except:
    exec(huj+miniMapm+' as miniMap')
try :
    exec(huj+wndMgrm+' as wndMgr')
except:
    exec(huj+wndMgrm+' as wndMgr')


try :
    exec(huj+chatm+' as chat')
except:
    exec(huj+chatm+' as chat')
try :
    exec(huj+localem+' as locale')
except:
    exec(huj+localem+' as locale')
try :
    exec(huj+localeinfom+' as localeinfo')
except:
    exec(huj+localeinfom+' as localeinfo')
try :
    exec(huj+netm+' as net')
except:
    exec(huj+netm+' as net')

try :
    exec(huj+skillm+' as skill')
except:
    exec(huj+skillm+' as skill')

try :
    exec (huj+chrm+' as chr')
except:
    exec (huj+chrm+' as chr')
try :
    exec (huj+chrmgrm+' as chrmgr')
except:
    exec (huj+chrmgrm+' as chrmgr')
try :
    exec (huj+sndm+' as snd')
except:
    exec (huj+sndm+' as snd')
try :
    exec (huj+grpm+' as grp')
except:
    exec (huj+grpm+' as grp')


try :
    exec (huj+shopm+' as shop')
except:
    exec (huj+shopm+' as shop')
try :
    exec (huj+textTailm+' as textTail')
except:
    exec (huj+textTailm+' as textTail')
try :
    import uiToolTip
    from uitooltip import ItemToolTip
except:
    pass

try :
    exec (huj+systemSettingm+' as systemSetting')
except:
    exec (huj+systemSettingm+' as systemSetting')
try :
    exec (huj+constInfom+' as constInfo')
except:
    exec (huj+constInfom+' as constInfo')
try :
    exec (huj+effectm+' as effect')
except:
    exec (huj+effectm+' as effect')
try :
    exec (huj+questm+' as quest')
except:
    exec (huj+questm+' as quest')
try :
    exec (huj+guildm+' as guild')
except:
    exec (huj+guildm+' as guild')
try :
    exec (huj+imem+' as ime')
except:
    exec (huj+imem+' as ime')

import m2k_lib

ListOfItems = [ [ 0 for x in xrange(2) ] for x in xrange(50) ]

class ShopDialog(ui.ScriptWindow):
	
	Gui = {}
	
	def __init__(self):
		self.Board = ui.ThinBoard() 
		self.Board.SetPosition(52, 40)
		self.Board.SetSize(350, 370)
	#	self.Board.AddFlag('movable')
		self.Board.Hide()
		
		self.comp = m2k_lib.Component()
		self.Header = self.comp.TextLine(self.Board, 'Shop-Creator', 145, 8, self.comp.RGB(255, 255, 0))
		self.Name = self.comp.TextLine(self.Board, 'Shop-Name:', 30, 310, self.comp.RGB(0, 229, 650))
	
		self.CloseButton = self.comp.Button(self.Board, '', 'Close', 329, 8, self.Hide_UI, 'd:/ymir work/ui/public/close_button_01.sub', 'd:/ymir work/ui/public/close_button_02.sub', 'd:/ymir work/ui/public/close_button_03.sub')
		self.MultiplicationButton = self.comp.Button(self.Board, 'Multiplication', '', 203, 340, self.SetMultiplication, 'd:/ymir work/ui/public/large_button_01.sub', 'd:/ymir work/ui/public/large_button_02.sub','d:/ymir work/ui/public/large_button_03.sub')
		self.MakeShopButton = self.comp.Button(self.Board, 'Make Shop', '', 61, 340, self.CreateShop, 'd:/ymir work/ui/public/large_button_01.sub', 'd:/ymir work/ui/public/large_button_02.sub','d:/ymir work/ui/public/large_button_03.sub')
		self.ShopNameSlotbar, self.ShopNameEditline = self.comp.EditLine(self.Board, '', 100, 310, 220, 18, 34)
		
		iX = 82
		eX = 10
		y = 30
		for line in xrange(20):
			self.Gui["Item"+str(line+1)] = self.comp.TextLine(self.Board, 'Item'+str(line+1), iX, y, self.comp.RGB(0, 229, 650))
			self.Gui["ItemPriceSlotBar"+str(line+1)], self.Gui["ItemPriceEditline"+str(line+1)] = self.comp.EditLine(self.Board, '0', eX, y, 67, 18, 9)
			y+=25
			if y == 280:
				y = 30
				iX = 257
				eX = 185
				
		self.ShopNameEditline.SetText(m2k_lib.ReadConfig("ShopName"))
		self.Multiplication = int(m2k_lib.ReadConfig("Multiplication"))
		
		if self.Multiplication:
			self.MultiplicationButton.SetText('Multiplication')
		else:
			self.MultiplicationButton.SetText('No Multiplication')
		
	#	for i in xrange(20):
	#		exec 'self.Gui["ItemPriceEditline'+ str(i+1) + '"]' + '.SetText("' + GetPrice(i) + '")'
	#	
	#	self.GetItems()	
		
	def switch_state(self):
		if self.Board.IsShow():
			self.Hide_UI()
		else:
			self.Shopw_UI()
	def Shopw_UI(self):
		self.Board.Show()
		for line in xrange(20):
			self.Gui["Item"+str(line+1)].Show()
			self.Gui["ItemPriceSlotBar"+str(line+1)].Show()
		for i in xrange(20):
			exec 'self.Gui["ItemPriceEditline'+ str(i+1) + '"]' + '.SetText("' + GetPrice(i) + '")'
		self.GetItems()		
		
	def Hide_UI(self):
		self.Board.Hide()
		m2k_lib.SaveConfig("ShopName", str(self.ShopNameEditline.GetText()))
		m2k_lib.SaveConfig("Multiplication", str(self.Multiplication))
		for i in xrange(20):
			exec 'SavePrice("price' + str(i+1)+'", str(self.Gui["ItemPriceEditline' + str(i+1) + '"]' + '.GetText()))'
	

	def SetMultiplication(self):
		if self.Multiplication:
			self.Multiplication = 0
			self.MultiplicationButton.SetText('No Multiplication')
			chat.AppendChat(7, '[m2k-Mod] Multiplication changed to no price nultiplication')
		else: 
			self.Multiplication = 1
			self.MultiplicationButton.SetText('Multiplication')
			chat.AppendChat(7, '[m2k-Mod] No price multiplication changed to multiplication')
		
	
	def CreateShop(self):
		price = 0
		for i in xrange(0, 40):
			ItemValue = player.GetItemIndex(i)
			if ItemValue == 50300:
				ItemValue = 100000 + player.GetItemMetinSocket(i, 0)
			if ItemValue != 0:
				for j in xrange(0,19):
					if ItemValue == ListOfItems[j][0]:
						exec 'price = int(self.Gui["ItemPriceEditline' + str(j+1) + '"]' + '.GetText())'
				if self.Multiplication:
					newPrice = int(price) * player.GetItemCount(i)
				else:
					newPrice = int(price)
				if int(newPrice) != 0:
					shop.AddPrivateShopItemStock(player.SLOT_TYPE_INVENTORY, int(i), int(i), int(newPrice))
				else:
					chat.AppendChat(7, '[m2k-Mod] Item not added to the Stock because of Price = 0')
		shop.BuildPrivateShop(self.ShopNameEditline.GetText())
		
	def GetItems(self):
		for ra in xrange(0,40):
			ListOfItems[ra][0] = 0
		for ri in xrange(0,40):
			disable = 0
			ItemValue = player.GetItemIndex(ri)
			if ((int(ItemValue) != 0) and (ItemValue != 50300)):
				item.SelectItem(ItemValue)
				for i in xrange(0,29):
					if (ListOfItems[i][0] == ItemValue):
						disable = 1
						break
					else:
						disable = 0
				if (disable == 0):
					for j in xrange(0,29):
						if (ListOfItems[j][0] == 0):
							ListOfItems[j][0] = ItemValue
							exec 'self.Gui["Item'+ str(j + 1) + '"]' + '.SetText("' + item.GetItemName() + '")'
							break
			if (ItemValue == 50300):
				sbId = player.GetItemMetinSocket(ri, 0)
				ItemValue = 100000 + sbId
				disable = 0
				for i in xrange(0, 19):
					if (ListOfItems[i][0] == ItemValue):
						disable = 1
						break
					else:
						disable = 0
				if (disable == 0):
					for j in xrange(0, 19):
						if (ListOfItems[j][0] == 0):
							ListOfItems[j][0] = ItemValue
							exec 'self.Gui["Item' + str(j + 1) + '"]' + '.SetText("' + str(skill.GetSkillName(sbId)) + '")'
							break
		CountItems = 0
		for hid in xrange(0, 20):
			if (ListOfItems[hid][0] == 0):
				exec 'self.Gui["Item' + str(hid+1) + '"]' + '.Hide()'
				exec 'self.Gui["ItemPriceSlotBar' + str(hid+1) + '"]' + '.Hide()'
			if (ListOfItems[hid][0] != 0):
				CountItems += 1

def GetPrice(line):
	handle = app.OpenTextFile('m2kmod/Saves/priceconfig.m2k')
	t = app.GetTextFileLine(handle, line)
	return t.split('=')[1]
		
def SavePrice(Setting, Value):
	sReader = open('m2kmod/Saves/priceconfig.m2k', 'r')
	sLines = file.readlines(sReader)
	sWriter = open('m2kmod/Saves/priceconfig.m2k', 'w')
	for Line in sLines:
		if Line.startswith(Setting + '='):
			Line = Setting + '=' + Value + '\n'
		sWriter.write(Line)
