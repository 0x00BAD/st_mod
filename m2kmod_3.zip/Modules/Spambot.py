exec ('import sys')
import time
import os
import math

b = sys.modules.keys()
for i in range (len(b)):
    h=b[i]
    r=0
    for g in range(len(h)):
        if h[g] != '.':
            r=r+1
            if r==len(h):
                a=dir(__import__(b[i]))
                for y in range(len(a)):
                    if a[y]=='SET_DEFAULT_FOG_LEVEL':
                        constInfom=b[i]
                    if a[y]=='APP_TITLE':
                        localeinfom=b[i]
                    if a[y]=='APP_TITLE':
                        localem=b[i]
                    if a[y]=='GetGuildAreaID':
                        minimapm=b[i]
                    if a[y]=='MoveLeft':
                        imem=b[i]
                    if a[y]=='GetGuildLevel':
                        guildm=b[i]
                    if a[y]=='GetQuestIndex':
                        questm=b[i]
                    if a[y]=='SetPosition':
                        effectm=b[i]
                    if a[y]=='PlaySound':
                        sndm=b[i]
                    if a[y]=='SetInterfaceRenderState':
                        grpm=b[i]
                    if a[y]=='IsPrivateShop':
                        shopm=b[i]
                    if a[y]=='LoadMap':
                        backgroundm=b[i]
                    if a[y]=='LogBox':
                        dbgm=b[i]
                    if a[y]=='GetScreenWidth':
                        wndMgrm=b[i]
                    if a[y]=='GetSkillName':
                        skillm=b[i]
                    if a[y]=='SetGeneralMotions':
                        playerSettingModulem=b[i]
                    if a[y]=='GetCurrentResolution':
                        systemSettingm=b[i]
                    if a[y]=='AppendChat':
                        chatm=b[i]
                    if a[y]=='Pick':
                        textTailm=b[i]
                    if a[y]=='SetMovingSpeed':
                        chrmgrm=b[i]
                    if a[y]=='LogBox':
                        dbgm=b[i]
                    if a[y]=='GetMainCharacterIndex':
                        playerm=b[i]
                    if a[y]=='GetNameByVID':
                        chrm=b[i]
                    if a[y]=='SendShopEndPacket':
                        netm=b[i]
                    if a[y]=='DIK_UP':
                        appm=b[i]
                    if a[y]=='SelectItem':
                        itemm=b[i]
                    if a[y]=='Button':
                        uim=b[i]
                    if a[y]=='mouseController':
                        mouseModulem=b[i]
                    if a[y]=='GetAtlasSize':
                        miniMapm=b[i]
                    if a[y]=='GetMousePosition':
                        wndMgrm=b[i]
                    if a[y]=='GameWindow':
                        gamem=b[i]
                    if a[y]=='GetAvailableMemory':
                        grpm=b[i]
                    if a[y]=='InputDialog':
                        uiCommonm=b[i]
                    if a[y]=='AtlasWindow':
                        uiminimapm=b[i]
                    if a[y]=='BeginEnvironment':
                        backgroundm=b[i]
                    if a[y]=='LoadNonPlayerData':
                        nonplayerm=b[i]
                    if a[y]=='SetPosition':
                        effectm=b[i]
                    if a[y]=='GetQuestIndex':
                        questm=b[i]
                    if a[y]=='GetGuildLevel':
                        guildm=b[i]
huj='import '
try:
    exec (huj+nonplayerm+' as nonplayer')
except:
    exec (huj+nonplayerm+' as nonplayer')
try:
    exec (huj+backgroundm+' as background')
except:
    exec (huj+backgroundm+' as background')
try:
    exec (huj+uiCommonm+' as uiCommon')
except:
    exec (huj+uiCommonm+' as uiCommon')
try:
    exec (huj+uiminimapm+' as uiminimap')
except:
    exec (huj+uiminimapm+' as uiminimap')
try:
    exec (huj+dbgm+' as dbg')
except:
    exec (huj+dbgm+' as dbg')
try:
    exec (huj+gamem+' as game')
except:
    exec (huj+gamem+' as game')

try:
    exec (huj+playerm+' as player')
except:
    exec (huj+playerm+' as player')
try:
    exec (huj+netm+' as net')
except:
    exec (huj+netm+' as net')
try:
    exec (huj+appm+' as app')
except:
    exec (huj+appm+' as app')
try :
    exec(huj+itemm+' as item')
except:
    exec(huj+itemm+' as item')

try :
    exec(huj+uim+' as ui')
except:
    exec(huj+uim+' as ui')
    
try :
    
    exec(huj+mouseModulem+' as mouseModule')
except:
    exec(huj+mouseModulem+' as mouseModule')
try :
    exec(huj+miniMapm+' as miniMap')
except:
    exec(huj+miniMapm+' as miniMap')
try :
    exec(huj+wndMgrm+' as wndMgr')
except:
    exec(huj+wndMgrm+' as wndMgr')


try :
    exec(huj+chatm+' as chat')
except:
    exec(huj+chatm+' as chat')
try :
    exec(huj+localem+' as locale')
except:
    exec(huj+localem+' as locale')
try :
    exec(huj+localeinfom+' as localeinfo')
except:
    exec(huj+localeinfom+' as localeinfo')
try :
    exec(huj+netm+' as net')
except:
    exec(huj+netm+' as net')

try :
    exec(huj+skillm+' as skill')
except:
    exec(huj+skillm+' as skill')

try :
    exec (huj+chrm+' as chr')
except:
    exec (huj+chrm+' as chr')
try :
    exec (huj+chrmgrm+' as chrmgr')
except:
    exec (huj+chrmgrm+' as chrmgr')
try :
    exec (huj+sndm+' as snd')
except:
    exec (huj+sndm+' as snd')
try :
    exec (huj+grpm+' as grp')
except:
    exec (huj+grpm+' as grp')


try :
    exec (huj+shopm+' as shop')
except:
    exec (huj+shopm+' as shop')
try :
    exec (huj+textTailm+' as textTail')
except:
    exec (huj+textTailm+' as textTail')
try :
    import uiToolTip
    from uitooltip import ItemToolTip
except:
    pass

try :
    exec (huj+systemSettingm+' as systemSetting')
except:
    exec (huj+systemSettingm+' as systemSetting')
try :
    exec (huj+constInfom+' as constInfo')
except:
    exec (huj+constInfom+' as constInfo')
try :
    exec (huj+effectm+' as effect')
except:
    exec (huj+effectm+' as effect')
try :
    exec (huj+questm+' as quest')
except:
    exec (huj+questm+' as quest')
try :
    exec (huj+guildm+' as guild')
except:
    exec (huj+guildm+' as guild')
try :
    exec (huj+imem+' as ime')
except:
    exec (huj+imem+' as ime')

import m2k_lib

class SpamDialog(ui.ScriptWindow):
	
	def __init__(self):
		self.Board = ui.ThinBoard()
		self.Board.SetSize(198, 245)
		self.Board.SetPosition(52, 40)
	#	self.Board.AddFlag('movable')
		self.Board.Hide()
		
		self.comp = m2k_lib.Component()
		self.Header = self.comp.TextLine(self.Board, 'Spambot', 73, 7, self.comp.RGB(255, 255, 0))
		self.DelayLabel = self.comp.TextLine(self.Board, 'Delay: 15 Sec.', 70, 163, self.comp.RGB(255, 255, 255))
		
		self.DelaySlide = self.comp.SliderBar(self.Board, 0.15, self.SlideFunc, 13, 148)
		self.Close = self.comp.Button(self.Board, '', 'Close', 175, 7, self.Hide_UI, 'd:/ymir work/ui/public/close_button_01.sub', 'd:/ymir work/ui/public/close_button_02.sub', 'd:/ymir work/ui/public/close_button_03.sub')
		self.ChatTypeButton = self.comp.Button(self.Board, 'Global', 'Chattype', 17, 113, self.SetType, 'd:/ymir work/ui/public/small_button_01.sub', 'd:/ymir work/ui/public/small_button_02.sub','d:/ymir work/ui/public/small_button_03.sub')
		self.SaveTextButton = self.comp.Button(self.Board, 'Save', '', 139, 113, self.SaveTextContent, 'd:/ymir work/ui/public/small_button_01.sub', 'd:/ymir work/ui/public/small_button_02.sub','d:/ymir work/ui/public/small_button_03.sub')
		self.SpamOn = self.comp.HideButton(self.Board, '', '', 80, 190, self.SetSpamStatus, 'm2kmod\Images\start_0.tga', 'm2kmod\Images\start_1.tga', 'm2kmod\Images\start_2.tga')
		self.SpamOff = self.comp.HideButton(self.Board, '', '', 75, 190, self.SetSpamStatus, 'm2kmod\Images\stop_0.tga', 'm2kmod\Images\stop_1.tga', 'm2kmod\Images\stop_2.tga')
		self.Slotbar, self.SpamText = self.comp.EditLine(self.Board, '', 23, 29, 150, 75, 150)
		self.SpamCombo = self.comp.ComboBoxFunc(self.Board, '<choose>', 69, 115, 60, self.GetTextContent)
		
		self.SpamStatus = int(m2k_lib.ReadConfig("SpamStatus"))
		self.Delay = int(m2k_lib.ReadConfig("SpamDelay"))
		self.CurrentNum = m2k_lib.ReadConfig("CurrentText")
		self.Type = m2k_lib.ReadConfig("Type")
	
		if self.SpamStatus == 1:
			self.SpamOff.Show()
			self.StartSpam()
		else:
			self.SpamOn.Show()
			self.StopSpam()
			
		if self.Type == "Normal":
			self.ChatTypeButton.SetText("Normal")
		else:
			self.ChatTypeButton.SetText("Global")
		
		list = ("Text1", "Text2", "Text3", "Text4", "Text5", "Text6", "Text7", "Text8") 
		for Account in list:
			self.SpamCombo.InsertItem(1,Account)
		self.SpamCombo.SetCurrentItem(self.CurrentNum)	
		self.GetTextContent()
		
		self.DelaySlide.SetSliderPos(float(self.Delay*0.01))
		self.SlideFunc()
		
	def switch_state(self):
		if self.Board.IsShow():
			self.Hide_UI()
		else:
			self.Board.Show()
	def Hide_UI(self):
		self.Board.Hide()
		m2k_lib.SaveConfig("SpamStatus", str(self.SpamStatus))
		m2k_lib.SaveConfig("SpamDelay", str(self.Delay))
		m2k_lib.SaveConfig("Type", str(self.Type))
		m2k_lib.SaveConfig("CurrentText", str(self.CurrentNum))
		
	
	def SlideFunc(self):
		self.Delay = int((self.DelaySlide.GetSliderPos()*100)+0.001)
		self.DelayLabel.SetText("Delay: "+str(self.Delay)+ " Sec.")
	
	def SetSpamStatus(self):
		if self.SpamStatus == 0:
			self.SpamStatus = 1
			chat.AppendChat(7, '[m2k-Mod] Spam-Bot started')	
			self.SpamOff.Show()
			self.SpamOn.Hide()
			self.StartSpam()
		else: 
			self.SpamStatus = 0
			chat.AppendChat(7, '[m2k-Mod] Spam-Bot stoped')	
			self.SpamOn.Show()
			self.SpamOff.Hide()	
			self.StopSpam()
	
	def SetType(self):
		if self.Type == "Normal":
			self.Type = "Global"
			chat.AppendChat(7, '[m2k-Mod] Spam-Mode changed to Globalchat-Spamming')
		else: 
			self.Type = "Normal"
			chat.AppendChat(7, '[m2k-Mod] Spam-Mode changed to Normalchat-Spamming')		
		self.ChatTypeButton.SetText(self.Type)

	def StartSpam(self):
		if self.Type == "Normal":
			net.SendChatPacket(str(self.SpamText.GetText()), chat.CHAT_TYPE_TALKING)
		else: 
			net.SendChatPacket(str(self.SpamText.GetText()), chat.CHAT_TYPE_SHOUT)
		
		self.UpdateSpam = m2k_lib.WaitingDialog()
		self.UpdateSpam.Open(self.Delay)
		self.UpdateSpam.SAFE_SetTimeOverEvent(self.StartSpam)
		
	def StopSpam(self):
		self.UpdateSpam = m2k_lib.WaitingDialog()
		self.UpdateSpam.Close()
		
	def GetTextContent(self):	
		self.SpamText.SetText(m2k_lib.ReadConfig(self.SpamCombo.GetCurrentText()))
		self.CurrentNum = self.SpamCombo.GetCurrentText()
	
	def SaveTextContent(self):
		m2k_lib.SaveConfig("Text"+str(num), self.SpamText.GetText())
