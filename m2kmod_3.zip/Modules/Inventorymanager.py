exec ('import sys')
import time
import os
import math

b = sys.modules.keys()
for i in range (len(b)):
    h=b[i]
    r=0
    for g in range(len(h)):
        if h[g] != '.':
            r=r+1
            if r==len(h):
                a=dir(__import__(b[i]))
                for y in range(len(a)):
                    if a[y]=='SET_DEFAULT_FOG_LEVEL':
                        constInfom=b[i]
                    if a[y]=='APP_TITLE':
                        localeinfom=b[i]
                    if a[y]=='APP_TITLE':
                        localem=b[i]
                    if a[y]=='GetGuildAreaID':
                        minimapm=b[i]
                    if a[y]=='MoveLeft':
                        imem=b[i]
                    if a[y]=='GetGuildLevel':
                        guildm=b[i]
                    if a[y]=='GetQuestIndex':
                        questm=b[i]
                    if a[y]=='SetPosition':
                        effectm=b[i]
                    if a[y]=='PlaySound':
                        sndm=b[i]
                    if a[y]=='SetInterfaceRenderState':
                        grpm=b[i]
                    if a[y]=='IsPrivateShop':
                        shopm=b[i]
                    if a[y]=='LoadMap':
                        backgroundm=b[i]
                    if a[y]=='LogBox':
                        dbgm=b[i]
                    if a[y]=='GetScreenWidth':
                        wndMgrm=b[i]
                    if a[y]=='GetSkillName':
                        skillm=b[i]
                    if a[y]=='SetGeneralMotions':
                        playerSettingModulem=b[i]
                    if a[y]=='GetCurrentResolution':
                        systemSettingm=b[i]
                    if a[y]=='AppendChat':
                        chatm=b[i]
                    if a[y]=='Pick':
                        textTailm=b[i]
                    if a[y]=='SetMovingSpeed':
                        chrmgrm=b[i]
                    if a[y]=='LogBox':
                        dbgm=b[i]
                    if a[y]=='GetMainCharacterIndex':
                        playerm=b[i]
                    if a[y]=='GetNameByVID':
                        chrm=b[i]
                    if a[y]=='SendShopEndPacket':
                        netm=b[i]
                    if a[y]=='DIK_UP':
                        appm=b[i]
                    if a[y]=='SelectItem':
                        itemm=b[i]
                    if a[y]=='Button':
                        uim=b[i]
                    if a[y]=='mouseController':
                        mouseModulem=b[i]
                    if a[y]=='GetAtlasSize':
                        miniMapm=b[i]
                    if a[y]=='GetMousePosition':
                        wndMgrm=b[i]
                    if a[y]=='GameWindow':
                        gamem=b[i]
                    if a[y]=='GetAvailableMemory':
                        grpm=b[i]
                    if a[y]=='InputDialog':
                        uiCommonm=b[i]
                    if a[y]=='AtlasWindow':
                        uiminimapm=b[i]
                    if a[y]=='BeginEnvironment':
                        backgroundm=b[i]
                    if a[y]=='LoadNonPlayerData':
                        nonplayerm=b[i]
                    if a[y]=='SetPosition':
                        effectm=b[i]
                    if a[y]=='GetQuestIndex':
                        questm=b[i]
                    if a[y]=='GetGuildLevel':
                        guildm=b[i]
huj='import '
try:
    exec (huj+nonplayerm+' as nonplayer')
except:
    exec (huj+nonplayerm+' as nonplayer')
try:
    exec (huj+backgroundm+' as background')
except:
    exec (huj+backgroundm+' as background')
try:
    exec (huj+uiCommonm+' as uiCommon')
except:
    exec (huj+uiCommonm+' as uiCommon')
try:
    exec (huj+uiminimapm+' as uiminimap')
except:
    exec (huj+uiminimapm+' as uiminimap')
try:
    exec (huj+dbgm+' as dbg')
except:
    exec (huj+dbgm+' as dbg')
try:
    exec (huj+gamem+' as game')
except:
    exec (huj+gamem+' as game')

try:
    exec (huj+playerm+' as player')
except:
    exec (huj+playerm+' as player')
try:
    exec (huj+netm+' as net')
except:
    exec (huj+netm+' as net')
try:
    exec (huj+appm+' as app')
except:
    exec (huj+appm+' as app')
try :
    exec(huj+itemm+' as item')
except:
    exec(huj+itemm+' as item')

try :
    exec(huj+uim+' as ui')
except:
    exec(huj+uim+' as ui')
    
try :
    
    exec(huj+mouseModulem+' as mouseModule')
except:
    exec(huj+mouseModulem+' as mouseModule')
try :
    exec(huj+miniMapm+' as miniMap')
except:
    exec(huj+miniMapm+' as miniMap')
try :
    exec(huj+wndMgrm+' as wndMgr')
except:
    exec(huj+wndMgrm+' as wndMgr')


try :
    exec(huj+chatm+' as chat')
except:
    exec(huj+chatm+' as chat')
try :
    exec(huj+localem+' as locale')
except:
    exec(huj+localem+' as locale')
try :
    exec(huj+localeinfom+' as localeinfo')
except:
    exec(huj+localeinfom+' as localeinfo')
try :
    exec(huj+netm+' as net')
except:
    exec(huj+netm+' as net')

try :
    exec(huj+skillm+' as skill')
except:
    exec(huj+skillm+' as skill')

try :
    exec (huj+chrm+' as chr')
except:
    exec (huj+chrm+' as chr')
try :
    exec (huj+chrmgrm+' as chrmgr')
except:
    exec (huj+chrmgrm+' as chrmgr')
try :
    exec (huj+sndm+' as snd')
except:
    exec (huj+sndm+' as snd')
try :
    exec (huj+grpm+' as grp')
except:
    exec (huj+grpm+' as grp')


try :
    exec (huj+shopm+' as shop')
except:
    exec (huj+shopm+' as shop')
try :
    exec (huj+textTailm+' as textTail')
except:
    exec (huj+textTailm+' as textTail')
try :
    import uiToolTip
    from uitooltip import ItemToolTip
except:
    pass

try :
    exec (huj+systemSettingm+' as systemSetting')
except:
    exec (huj+systemSettingm+' as systemSetting')
try :
    exec (huj+constInfom+' as constInfo')
except:
    exec (huj+constInfom+' as constInfo')
try :
    exec (huj+effectm+' as effect')
except:
    exec (huj+effectm+' as effect')
try :
    exec (huj+questm+' as quest')
except:
    exec (huj+questm+' as quest')
try :
    exec (huj+guildm+' as guild')
except:
    exec (huj+guildm+' as guild')
try :
    exec (huj+imem+' as ime')
except:
    exec (huj+imem+' as ime')
    
import m2k_lib

class InventoryDialog(ui.ScriptWindow):

	def __init__(self):
		self.Board = ui.ThinBoard()
		self.Board.SetSize(210, 390)
		self.Board.SetPosition(52, 40)
	#	self.Board.AddFlag('movable')
		self.Board.Hide()
		
		self.comp = m2k_lib.Component()
		self.Header = self.comp.TextLine(self.Board, 'Inventory Manager', 61, 8, self.comp.RGB(255, 255, 0))
		self.ListBoxLabel = self.comp.TextLine(self.Board, ' Slot:	 ID:			Name:', 8, 33, self.comp.RGB(0, 229, 650))
		self.UpgradeLabel = self.comp.TextLine(self.Board, 'Upgrade			x', 70, 308, self.comp.RGB(255, 255, 255))
		
		self.Close = self.comp.Button(self.Board, '', 'Close', 188, 7, self.Board.Hide, 'd:/ymir work/ui/public/close_button_01.sub', 'd:/ymir work/ui/public/close_button_02.sub', 'd:/ymir work/ui/public/close_button_03.sub')
		self.Refresh = self.comp.Button(self.Board, '', 'Refresh', 163, 6, self.UpdateFileList, 'd:/ymir work/ui/game/guild/refresh_button_01.sub', 'd:/ymir work/ui/game/guild/refresh_button_02.sub', 'd:/ymir work/ui/game/guild/refresh_button_03.sub')
		self.UpgradeButton = self.comp.Button(self.Board, 'Upgrade', '', 110, 280, self.Upgrade, 'd:/ymir work/ui/public/Large_button_01.sub', 'd:/ymir work/ui/public/Large_button_02.sub','d:/ymir work/ui/public/Large_button_03.sub')
		self.DropSelectedButton = self.comp.Button(self.Board, 'Drop Selected', 'Drops all same Items like the selected one', 15, 333, self.DropItem, 'd:/ymir work/ui/public/Large_button_01.sub', 'd:/ymir work/ui/public/Large_button_02.sub','d:/ymir work/ui/public/Large_button_03.sub')
		self.DropAllButton = self.comp.Button(self.Board, 'Drop All', 'Drops ALL Items in your Inventory', 110, 333, self.DropAllItemsRequest, 'd:/ymir work/ui/public/Large_button_01.sub', 'd:/ymir work/ui/public/Large_button_02.sub','d:/ymir work/ui/public/Large_button_03.sub')
		self.SellSelectedButton = self.comp.Button(self.Board, 'Sell Selected', 'Sells all same Items like the selected one', 15, 358, self.SellItem, 'd:/ymir work/ui/public/Large_button_01.sub', 'd:/ymir work/ui/public/Large_button_02.sub','d:/ymir work/ui/public/Large_button_03.sub')
		self.SellAllButton = self.comp.Button(self.Board, 'Sell All', 'Sells ALL Items in your Inventory', 110, 358, self.SellAllItemsRequest, 'd:/ymir work/ui/public/Large_button_01.sub', 'd:/ymir work/ui/public/Large_button_02.sub','d:/ymir work/ui/public/Large_button_03.sub')
		self.UpgradeSlotbar, self.UpgradeEditline = self.comp.EditLine(self.Board, '1', 112, 307, 15, 18, 1)
		self.BarItems, self.ListBoxItems, ScrollItems = self.comp.ListBoxEx(self.Board, 10, 50, 170, 220)
		self.ModeCombo = self.comp.ComboBox(self.Board, 'Normal', 20, 282, 70)
		UppModes = ['Normal', 'DT', 'Guild', 'Bless', 'Metal', 'Normal - All']
		for Mode in UppModes:
			self.ModeCombo.InsertItem(0, Mode)
		self.UpgradeEditline.SetNumberMode()
		
		self.UpdateFileList()
		
	def switch_state(self):
		if self.Board.IsShow():
			self.Board.Hide()
		else:
			self.Board.Show()
			self.UpdateFileList()
			self.SegiID = int(m2k_lib.ReadConfig("Blessing-Scroll"))
			self.MetalID = int(m2k_lib.ReadConfig("Magic-Stone"))

		
	def UpdateFileList(self):
		self.ListBoxItems.RemoveAllItems()
		for i in xrange(100):
			ItemIndex = player.GetItemIndex(i)
			if ItemIndex != 0:
				ItemName = item.GetItemName(item.SelectItem(int(ItemIndex)))
				self.ListBoxItems.AppendItem(m2k_lib.Item(str(i) + '    ' + str(player.GetItemIndex(i)) + '    ' + ItemName))
				
	def Upgrade(self):
		ItemIndex = self.ListBoxItems.GetSelectedItem()
		if ItemIndex:
			pass
		else:
			chat.AppendChat(7, "[m2k-Mod] No Item selected!")
			return
		try:
			SearchedName = ItemIndex.GetText().split("    ")[2].split("+")[0]
		except:
			SearchedName = ItemIndex.GetText().split("    ")[2]
		
		SelectedItem = ItemIndex.GetText().split("    ")
		count = int(self.UpgradeEditline.GetText())
	
		if self.ModeCombo.GetCurrentText() == 'Normal':
			self.UpgradeItem(1,int(SelectedItem[0]), int(count))
		elif self.ModeCombo.GetCurrentText() == 'DT':
			self.UpgradeItem(2,int(SelectedItem[0]), int(count))
		elif self.ModeCombo.GetCurrentText() == 'Guild':
			self.UpgradeItem(3,int(SelectedItem[0]), int(count))
		elif self.ModeCombo.GetCurrentText() == 'Bless':
			self.UpgradeItem(4,int(SelectedItem[0]), int(count))
		elif self.ModeCombo.GetCurrentText() == 'Normal - All':
			for j in xrange(0, 90):
				ItemValue = player.GetItemIndex(j)
				try:
					ItemName = item.GetItemName(item.SelectItem(ItemValue)).split("+")[0]
				except:
					ItemName = item.GetItemName(item.SelectItem(ItemValue))
				if ItemName == SearchedName:
					self.UpgradeItem(1, j, int(count))
		elif self.ModeCombo.GetCurrentText() == 'Metal':
			self.UpgradeItem(5,int(SelectedItem[0]), int(count))
	
	def UpgradeItem(self, Mode, Slot, Count):
		self.BannedSlotIndex = []
		for i in xrange(Count):
			if Mode == 1:
				net.SendRefinePacket(Slot, 0)
			elif Mode == 2:
				net.SendRefinePacket(Slot, 4)
			elif Mode == 3:
				net.SendRefinePacket(Slot, 1)
			elif Mode == 4 or Mode == 5:
				for InventorySlot in xrange(player.INVENTORY_PAGE_SIZE*2):
					ItemValue = player.GetItemIndex(InventorySlot)
					if Mode == 4:
						if ItemValue == self.SegiID and not InventorySlot in self.BannedSlotIndex:
							self.BannedSlotIndex.append(InventorySlot)
							net.SendItemUseToItemPacket(InventorySlot, Slot)
							net.SendRefinePacket(Slot, 2)
							break
					elif Mode == 5:	
						if ItemValue == self.MetalID and not InventorySlot in self.BannedSlotIndex:
							self.BannedSlotIndex.append(InventorySlot)
							net.SendItemUseToItemPacket(InventorySlot, Slot)
							net.SendRefinePacket(Slot, 2)
							break
		self.UpdateFileList()
						
	def SellItem(self):
		if not shop.IsOpen():
			chat.AppendChat(7, "[m2k-Mod] You need an open Shop for that!")
			return
		ItemIndex = self.ListBoxItems.GetSelectedItem()
		if ItemIndex:
			pass
		else:
			chat.AppendChat(7, "[m2k-Mod] No selctd Items!")
			return
		SelectedItem = ItemIndex.GetText().split("    ")	
		net.SendShopSellPacket(int(SelectedItem[0]))
		self.UpdateFileList()
		
	def DropItem(self):
		ItemIndex = self.ListBoxItems.GetSelectedItem()
		if ItemIndex:
			pass
		else:
			chat.AppendChat(7, "[m2k-Mod] No selctd Items!")
			return
		SelectedItem = ItemIndex.GetText().split("    ")	
		net.SendItemDropPacket(int(SelectedItem[0]))
		self.UpdateFileList()

	def SellAllItemsRequest(self):
		if not shop.IsOpen():
			chat.AppendChat(7, "[m2k-Mod] You need an open Shop for that!")
			return 
		self.QuestionDialog = uiCommon.QuestionDialog()
		self.QuestionDialog.SetText("Do you want so sell All your Items?")
		self.QuestionDialog.SetAcceptEvent(ui.__mem_func__(self.SellAll))
		self.QuestionDialog.SetCancelEvent(ui.__mem_func__(self.CancelQuestionDialog))
		self.QuestionDialog.Open()
	def SellAll(self):
		for i in xrange(90):
			net.SendShopSellPacket(i)
		self.CancelQuestionDialog()
		self.UpdateFileList()
		
	def DropAllItemsRequest(self):
		self.QuestionDialog = uiCommon.QuestionDialog()
		self.QuestionDialog.SetText("Do you want to drop ALL your Items?")
		self.QuestionDialog.SetAcceptEvent(ui.__mem_func__(self.DropAll))
		self.QuestionDialog.SetCancelEvent(ui.__mem_func__(self.CancelQuestionDialog))
		self.QuestionDialog.Open()
	def DropAll(self):
		for i in xrange(90):
			net.SendItemDropPacket(i)
		self.CancelQuestionDialog()
		self.UpdateFileList()
		
	def CancelQuestionDialog(self):
		self.QuestionDialog.Close()
		self.QuestionDialog = None


	
