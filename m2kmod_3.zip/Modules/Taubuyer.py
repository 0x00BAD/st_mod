exec ('import sys')
import time
import os
import math

b = sys.modules.keys()
for i in range (len(b)):
    h=b[i]
    r=0
    for g in range(len(h)):
        if h[g] != '.':
            r=r+1
            if r==len(h):
                a=dir(__import__(b[i]))
                for y in range(len(a)):
                    if a[y]=='SET_DEFAULT_FOG_LEVEL':
                        constInfom=b[i]
                    if a[y]=='APP_TITLE':
                        localeinfom=b[i]
                    if a[y]=='APP_TITLE':
                        localem=b[i]
                    if a[y]=='GetGuildAreaID':
                        minimapm=b[i]
                    if a[y]=='MoveLeft':
                        imem=b[i]
                    if a[y]=='GetGuildLevel':
                        guildm=b[i]
                    if a[y]=='GetQuestIndex':
                        questm=b[i]
                    if a[y]=='SetPosition':
                        effectm=b[i]
                    if a[y]=='PlaySound':
                        sndm=b[i]
                    if a[y]=='SetInterfaceRenderState':
                        grpm=b[i]
                    if a[y]=='IsPrivateShop':
                        shopm=b[i]
                    if a[y]=='LoadMap':
                        backgroundm=b[i]
                    if a[y]=='LogBox':
                        dbgm=b[i]
                    if a[y]=='GetScreenWidth':
                        wndMgrm=b[i]
                    if a[y]=='GetSkillName':
                        skillm=b[i]
                    if a[y]=='SetGeneralMotions':
                        playerSettingModulem=b[i]
                    if a[y]=='GetCurrentResolution':
                        systemSettingm=b[i]
                    if a[y]=='AppendChat':
                        chatm=b[i]
                    if a[y]=='Pick':
                        textTailm=b[i]
                    if a[y]=='SetMovingSpeed':
                        chrmgrm=b[i]
                    if a[y]=='LogBox':
                        dbgm=b[i]
                    if a[y]=='GetMainCharacterIndex':
                        playerm=b[i]
                    if a[y]=='GetNameByVID':
                        chrm=b[i]
                    if a[y]=='SendShopEndPacket':
                        netm=b[i]
                    if a[y]=='DIK_UP':
                        appm=b[i]
                    if a[y]=='SelectItem':
                        itemm=b[i]
                    if a[y]=='Button':
                        uim=b[i]
                    if a[y]=='mouseController':
                        mouseModulem=b[i]
                    if a[y]=='GetAtlasSize':
                        miniMapm=b[i]
                    if a[y]=='GetMousePosition':
                        wndMgrm=b[i]
                    if a[y]=='GameWindow':
                        gamem=b[i]
                    if a[y]=='GetAvailableMemory':
                        grpm=b[i]
                    if a[y]=='InputDialog':
                        uiCommonm=b[i]
                    if a[y]=='AtlasWindow':
                        uiminimapm=b[i]
                    if a[y]=='BeginEnvironment':
                        backgroundm=b[i]
                    if a[y]=='LoadNonPlayerData':
                        nonplayerm=b[i]
                    if a[y]=='SetPosition':
                        effectm=b[i]
                    if a[y]=='GetQuestIndex':
                        questm=b[i]
                    if a[y]=='GetGuildLevel':
                        guildm=b[i]
huj='import '
try:
    exec (huj+nonplayerm+' as nonplayer')
except:
    exec (huj+nonplayerm+' as nonplayer')
try:
    exec (huj+backgroundm+' as background')
except:
    exec (huj+backgroundm+' as background')
try:
    exec (huj+uiCommonm+' as uiCommon')
except:
    exec (huj+uiCommonm+' as uiCommon')
try:
    exec (huj+uiminimapm+' as uiminimap')
except:
    exec (huj+uiminimapm+' as uiminimap')
try:
    exec (huj+dbgm+' as dbg')
except:
    exec (huj+dbgm+' as dbg')
try:
    exec (huj+gamem+' as game')
except:
    exec (huj+gamem+' as game')

try:
    exec (huj+playerm+' as player')
except:
    exec (huj+playerm+' as player')
try:
    exec (huj+netm+' as net')
except:
    exec (huj+netm+' as net')
try:
    exec (huj+appm+' as app')
except:
    exec (huj+appm+' as app')
try :
    exec(huj+itemm+' as item')
except:
    exec(huj+itemm+' as item')

try :
    exec(huj+uim+' as ui')
except:
    exec(huj+uim+' as ui')
    
try :
    
    exec(huj+mouseModulem+' as mouseModule')
except:
    exec(huj+mouseModulem+' as mouseModule')
try :
    exec(huj+miniMapm+' as miniMap')
except:
    exec(huj+miniMapm+' as miniMap')
try :
    exec(huj+wndMgrm+' as wndMgr')
except:
    exec(huj+wndMgrm+' as wndMgr')


try :
    exec(huj+chatm+' as chat')
except:
    exec(huj+chatm+' as chat')
try :
    exec(huj+localem+' as locale')
except:
    exec(huj+localem+' as locale')
try :
    exec(huj+localeinfom+' as localeinfo')
except:
    exec(huj+localeinfom+' as localeinfo')
try :
    exec(huj+netm+' as net')
except:
    exec(huj+netm+' as net')

try :
    exec(huj+skillm+' as skill')
except:
    exec(huj+skillm+' as skill')

try :
    exec (huj+chrm+' as chr')
except:
    exec (huj+chrm+' as chr')
try :
    exec (huj+chrmgrm+' as chrmgr')
except:
    exec (huj+chrmgrm+' as chrmgr')
try :
    exec (huj+sndm+' as snd')
except:
    exec (huj+sndm+' as snd')
try :
    exec (huj+grpm+' as grp')
except:
    exec (huj+grpm+' as grp')


try :
    exec (huj+shopm+' as shop')
except:
    exec (huj+shopm+' as shop')
try :
    exec (huj+textTailm+' as textTail')
except:
    exec (huj+textTailm+' as textTail')
try :
    import uiToolTip
    from uitooltip import ItemToolTip
except:
    pass

try :
    exec (huj+systemSettingm+' as systemSetting')
except:
    exec (huj+systemSettingm+' as systemSetting')
try :
    exec (huj+constInfom+' as constInfo')
except:
    exec (huj+constInfom+' as constInfo')
try :
    exec (huj+effectm+' as effect')
except:
    exec (huj+effectm+' as effect')
try :
    exec (huj+questm+' as quest')
except:
    exec (huj+questm+' as quest')
try :
    exec (huj+guildm+' as guild')
except:
    exec (huj+guildm+' as guild')
try :
    exec (huj+imem+' as ime')
except:
    exec (huj+imem+' as ime')

from m2kmod.Modules import m2k_lib
import math

class TauAutobuyDialog(ui.ScriptWindow):

	Taus = [50821, 50822, 50823, 50824, 50825, 50826]
	PotionValue = [100, 5]
	State = 0
	
	def __init__(self):
		self.Board = ui.ThinBoard()
		self.Board.SetSize(200, 250)
		self.Board.SetPosition(52, 40)
		self.Board.AddFlag("movable")
		self.Board.Hide()
		
		self.comp = m2k_lib.Component()
		self.Header = self.comp.TextLine(self.Board, 'Potion-Buyer', 75, 8, self.comp.RGB(255, 255, 0))
		self.MinimumLabel = self.comp.TextLine(self.Board, 'Minimum Value:', 70, 60, self.comp.RGB(153, 178, 255))
		self.DurationLabel = self.comp.TextLine(self.Board, 'Duration:', 82, 110, self.comp.RGB(153, 178, 255))
		self.Value = self.comp.TextLine(self.Board, '+ 100', 85, 88, self.comp.RGB(255, 255, 255))
		self.Duration =self.comp.TextLine(self.Board, '10 Min.', 87, 138, self.comp.RGB(255, 255, 255))
		
		self.SlidbarValue = self.comp.SliderBar(self.Board, 0.5, self.SetConfig, 12, 75)
		self.SlidebarTime = self.comp.SliderBar(self.Board, 0.33, self.SetConfig, 12, 125)
		self.TauCombo = self.comp.ComboBox(self.Board, '<choose potion>', 35, 30, 135)

		self.Close = self.comp.Button(self.Board, '', 'Close', 183, 8, self.Board.Hide, 'd:/ymir work/ui/public/close_button_01.sub', 'd:/ymir work/ui/public/close_button_02.sub', 'd:/ymir work/ui/public/close_button_03.sub')
		self.BuyOn = self.comp.Button(self.Board, '', '', 80, 170, self.SetPotionStatus, 'm2kmod\Images\start_0.tga', 'm2kmod\Images\start_1.tga', 'm2kmod\Images\start_2.tga')
		self.BuyOff = self.comp.HideButton(self.Board, '', '', 80, 170, self.SetPotionStatus, 'm2kmod\Images\stop_0.tga', 'm2kmod\Images\stop_1.tga', 'm2kmod\Images\stop_2.tga')
		
		if player.GetName() != "":
			for Tau in self.Taus:
				self.TauCombo.InsertItem(1,str(Tau) + "  " + str(item.GetItemName(item.SelectItem(Tau))))
		
	def switch_state(self):
		if self.Board.IsShow():
			self.Board.Hide()
		else:
			self.Board.Show()
			
	
	def SetConfig(self):
		Value, Time = self.PotionValue
		MinValue = int(self.SlidbarValue.GetSliderPos() * 200)
		MinTime = int(self.SlidebarTime.GetSliderPos() * 30)
		if MinValue != Value:
			self.Value.SetText("+ " + str(MinValue))
		if MinTime != Time:
			self.Duration.SetText(str(MinTime) + " Min.")
			
		self.PotionValue = [MinValue, MinTime]
	
	def SetPotionStatus(self):
		if not shop.IsOpen():
			chat.AppendChat(7, "[m2k-Mod] Please open a Shop first!")
			return
		ItemIndex = self.TauCombo.GetCurrentText()
		if ItemIndex == "<choose potion>":
			chat.AppendChat(chat.CHAT_TYPE_INFO, "Please select an Item!")
			return
		if self.State:
			self.StopBuying()
		else:
			self.State = 1
			self.Spam = 0
			self.BuyOn.Hide()
			self.BuyOff.Show()
			self.StartBuying()
	

	def StartBuying(self):
		SelectedIndex = self.TauCombo.GetCurrentText()
		MinValue, MinTime = self.PotionValue
		MinTime = MinTime * 60
		PotionValue = int(SelectedIndex.split("  ")[0])
		
		for InventorySlot in xrange(player.INVENTORY_PAGE_SIZE*2):
			ItemIndex = player.GetItemIndex(InventorySlot)
			if PotionValue == ItemIndex:
				Value0, Value , Time = [player.GetItemMetinSocket(InventorySlot, i) for i in xrange(player.METIN_SOCKET_MAX_NUM)]
				if Value >= MinValue and Time >= MinTime:
					self.StopBuying()
					return
				else:
					net.SendShopSellPacket(InventorySlot)
		Slot = 0
		if shop.IsOpen():
			for EachShopSlot in xrange(shop.SHOP_SLOT_COUNT):
				ShopItemValue = shop.GetItemID(EachShopSlot)
				if ShopItemValue == int(PotionValue):
					Slot = EachShopSlot
					break
		else:
			chat.AppendChat(7, "[m2k-Mod] No Shop is open!")
			self.StopBuying()
			return
			
		if Slot != 0 and shop.IsOpen():	
			net.SendShopBuyPacket(Slot)
		else:
			chat.AppendChat(7, "[m2k-Mod] Cant find " + SelectedIndex.split("  ")[1] + " in shop!")
			self.StopBuying()
			return
		
		self.UpdateBuying = m2k_lib.WaitingDialog()			
		self.UpdateBuying.Open(1.0)
		self.UpdateBuying.SAFE_SetTimeOverEvent(self.StartBuying)
	
	def StopBuying(self):
		self.State = 0
		self.BuyOff.Hide()
		self.BuyOn.Show()
		self.UpdateBuying = m2k_lib.WaitingDialog()	
		self.UpdateBuying.Close()
						
#TauAutobuyDialog().Show()