exec ('import sys')
import time
import os
import math

b = sys.modules.keys()
for i in range (len(b)):
    h=b[i]
    r=0
    for g in range(len(h)):
        if h[g] != '.':
            r=r+1
            if r==len(h):
                a=dir(__import__(b[i]))
                for y in range(len(a)):
                    if a[y]=='SET_DEFAULT_FOG_LEVEL':
                        constInfom=b[i]
                    if a[y]=='APP_TITLE':
                        localeinfom=b[i]
                    if a[y]=='APP_TITLE':
                        localem=b[i]
                    if a[y]=='GetGuildAreaID':
                        minimapm=b[i]
                    if a[y]=='MoveLeft':
                        imem=b[i]
                    if a[y]=='GetGuildLevel':
                        guildm=b[i]
                    if a[y]=='GetQuestIndex':
                        questm=b[i]
                    if a[y]=='SetPosition':
                        effectm=b[i]
                    if a[y]=='PlaySound':
                        sndm=b[i]
                    if a[y]=='SetInterfaceRenderState':
                        grpm=b[i]
                    if a[y]=='IsPrivateShop':
                        shopm=b[i]
                    if a[y]=='LoadMap':
                        backgroundm=b[i]
                    if a[y]=='LogBox':
                        dbgm=b[i]
                    if a[y]=='GetScreenWidth':
                        wndMgrm=b[i]
                    if a[y]=='GetSkillName':
                        skillm=b[i]
                    if a[y]=='SetGeneralMotions':
                        playerSettingModulem=b[i]
                    if a[y]=='GetCurrentResolution':
                        systemSettingm=b[i]
                    if a[y]=='AppendChat':
                        chatm=b[i]
                    if a[y]=='Pick':
                        textTailm=b[i]
                    if a[y]=='SetMovingSpeed':
                        chrmgrm=b[i]
                    if a[y]=='LogBox':
                        dbgm=b[i]
                    if a[y]=='GetMainCharacterIndex':
                        playerm=b[i]
                    if a[y]=='GetNameByVID':
                        chrm=b[i]
                    if a[y]=='SendShopEndPacket':
                        netm=b[i]
                    if a[y]=='DIK_UP':
                        appm=b[i]
                    if a[y]=='SelectItem':
                        itemm=b[i]
                    if a[y]=='Button':
                        uim=b[i]
                    if a[y]=='mouseController':
                        mouseModulem=b[i]
                    if a[y]=='GetAtlasSize':
                        miniMapm=b[i]
                    if a[y]=='GetMousePosition':
                        wndMgrm=b[i]
                    if a[y]=='GameWindow':
                        gamem=b[i]
                    if a[y]=='GetAvailableMemory':
                        grpm=b[i]
                    if a[y]=='InputDialog':
                        uiCommonm=b[i]
                    if a[y]=='AtlasWindow':
                        uiminimapm=b[i]
                    if a[y]=='BeginEnvironment':
                        backgroundm=b[i]
                    if a[y]=='LoadNonPlayerData':
                        nonplayerm=b[i]
                    if a[y]=='SetPosition':
                        effectm=b[i]
                    if a[y]=='GetQuestIndex':
                        questm=b[i]
                    if a[y]=='GetGuildLevel':
                        guildm=b[i]
huj='import '
try:
    exec (huj+nonplayerm+' as nonplayer')
except:
    exec (huj+nonplayerm+' as nonplayer')
try:
    exec (huj+backgroundm+' as background')
except:
    exec (huj+backgroundm+' as background')
try:
    exec (huj+uiCommonm+' as uiCommon')
except:
    exec (huj+uiCommonm+' as uiCommon')
try:
    exec (huj+uiminimapm+' as uiminimap')
except:
    exec (huj+uiminimapm+' as uiminimap')
try:
    exec (huj+dbgm+' as dbg')
except:
    exec (huj+dbgm+' as dbg')
try:
    exec (huj+gamem+' as game')
except:
    exec (huj+gamem+' as game')

try:
    exec (huj+playerm+' as player')
except:
    exec (huj+playerm+' as player')
try:
    exec (huj+netm+' as net')
except:
    exec (huj+netm+' as net')
try:
    exec (huj+appm+' as app')
except:
    exec (huj+appm+' as app')
try :
    exec(huj+itemm+' as item')
except:
    exec(huj+itemm+' as item')

try :
    exec(huj+uim+' as ui')
except:
    exec(huj+uim+' as ui')
    
try :
    
    exec(huj+mouseModulem+' as mouseModule')
except:
    exec(huj+mouseModulem+' as mouseModule')
try :
    exec(huj+miniMapm+' as miniMap')
except:
    exec(huj+miniMapm+' as miniMap')
try :
    exec(huj+wndMgrm+' as wndMgr')
except:
    exec(huj+wndMgrm+' as wndMgr')


try :
    exec(huj+chatm+' as chat')
except:
    exec(huj+chatm+' as chat')
try :
    exec(huj+localem+' as locale')
except:
    exec(huj+localem+' as locale')
try :
    exec(huj+localeinfom+' as localeinfo')
except:
    exec(huj+localeinfom+' as localeinfo')
try :
    exec(huj+netm+' as net')
except:
    exec(huj+netm+' as net')

try :
    exec(huj+skillm+' as skill')
except:
    exec(huj+skillm+' as skill')

try :
    exec (huj+chrm+' as chr')
except:
    exec (huj+chrm+' as chr')
try :
    exec (huj+chrmgrm+' as chrmgr')
except:
    exec (huj+chrmgrm+' as chrmgr')
try :
    exec (huj+sndm+' as snd')
except:
    exec (huj+sndm+' as snd')
try :
    exec (huj+grpm+' as grp')
except:
    exec (huj+grpm+' as grp')


try :
    exec (huj+shopm+' as shop')
except:
    exec (huj+shopm+' as shop')
try :
    exec (huj+textTailm+' as textTail')
except:
    exec (huj+textTailm+' as textTail')
try :
    import uiToolTip
    from uitooltip import ItemToolTip
except:
    pass

try :
    exec (huj+systemSettingm+' as systemSetting')
except:
    exec (huj+systemSettingm+' as systemSetting')
try :
    exec (huj+constInfom+' as constInfo')
except:
    exec (huj+constInfom+' as constInfo')
try :
    exec (huj+effectm+' as effect')
except:
    exec (huj+effectm+' as effect')
try :
    exec (huj+questm+' as quest')
except:
    exec (huj+questm+' as quest')
try :
    exec (huj+guildm+' as guild')
except:
    exec (huj+guildm+' as guild')
try :
    exec (huj+imem+' as ime')
except:
    exec (huj+imem+' as ime')

import math,uiMiniMap,m2k_lib,exception

TeleportHackMode = "Teleport"		

class TeleportHackDialog(ui.ScriptWindow):

	CurrentMapName = ""
	
	class AtlasRenderer(ui.Window):
		TeleportState = 1
		def __init__(self):
			ui.Window.__init__(self)
			self.AddFlag("not_pick")
	#		self.AddFlag('movable')

		def OnUpdate(self):
			miniMap.UpdateAtlas()

		def OnRender(self):
			(PosX, PosY) = self.GetGlobalPosition()
			miniMap.RenderAtlas(float(PosX), float(PosY))
			
			if self.TeleportState == 0:
				self.Debug()
				
			if app.IsPressed(app.DIK_LSHIFT) and self.TeleportState == 1:
				(mouseX, mouseY) = wndMgr.GetMousePosition()
				(bFind, sName, iPosX, iPosY, dwTextColor, dwGuildID) = miniMap.GetAtlasInfo(mouseX, mouseY)
				
				(iSizeX, iSizeY, SizeX, SizeY) = GetCurrentMapSize()
				
				if not bFind:
					width = 6
					MapSizeX = miniMap.GetAtlasSize()[1]
					if MapSizeX == 0:
						size = 6
					else:
						size = DivideToFloat(SizeX * 256, miniMap.GetAtlasSize()[1])
					(sName, iPosX, iPosY, dwTextColor) = "", (mouseX - PosX) * size + width, (mouseY - PosY) * size, -8722595
				
				if iPosX < 0 or iPosY < 0 or iPosX > SizeX * 256 or iPosY > SizeY * 256:
					return

				self.TeleportState = 0
				
				self.TeleportToDest(iPosX*100, iPosY*100)

		def TeleportToDest(self, aimx, aimy):
			global TeleportHackMode
			if TeleportHackMode == "Walk":
				myVid = player.GetMainCharacterIndex()
				chr.MoveToDestPosition(int(myVid), int(aimx), int(aimy))
				self.TeleportState = 1
			else:		
				(TmpX, TmpY, Count) = GetTmpTeleport(aimx, aimy)
				TmpCount = 0
				
				while TmpCount < Count:
					(TmpX, TmpY, Crap) = GetTmpTeleport(aimx, aimy)
					chr.SetPixelPosition(int(TmpX), int(TmpY))
					TmpCount += 1
					self.Debug()
					
				chr.SetPixelPosition(int(aimx), int(aimy))
				self.Debug()
				self.TeleportState = 1

		def Debug(self):
			player.SetSingleDIKKeyState(app.DIK_UP, TRUE)
			player.SetSingleDIKKeyState(app.DIK_UP, FALSE)			

		def ShowAtlas(self):
			miniMap.ShowAtlas()

		def HideAtlas(self):
			miniMap.HideAtlas()

	def __init__(self):
		self.tooltipInfo = uiMiniMap.MapTextToolTip()
		self.tooltipInfo.Hide()
		self.AtlasMainWindow = None
		self.board = 0
		self.CurrentMapName = background.GetCurrentMapName()
		ui.ScriptWindow.__init__(self)
		self.LoadWindow()
		chat.AppendChat(7, '[m2k-Mod] Please teleport in small steps! ')	

	def LoadWindow(self):
		try:
			pyScrLoader = ui.PythonScriptLoader()
			pyScrLoader.LoadScriptFile(self, "UIScript/AtlasWindow.py")
		except:
			exception.Abort("AtlasWindow.LoadWindow.LoadScript")

		try:
			self.board = self.GetChild("board")
			self.board.SetTitleName("Teleporthack")

		except:
			exception.Abort("AtlasWindow.LoadWindow.BindObject")

		self.AtlasMainWindow = self.AtlasRenderer()
		self.board.SetCloseEvent(self.Hide)
		self.AtlasMainWindow.SetParent(self.board)
		self.AtlasMainWindow.SetPosition(7, 30)
		self.tooltipInfo.SetParent(self.board)
		self.SetPosition(52, 40)
		
		self.Line = ui.Line()
		self.Line.SetParent(self)
		self.Line.SetColor(0xff777777)
		self.Line.Show()
		
		self.ModeText = ui.TextLine()
		self.ModeText.SetParent(self)
		self.ModeText.SetText("Mode:")
		self.ModeText.Show()

		self.PositionText = ui.TextLine()
		self.PositionText.SetParent(self)
		self.PositionText.SetFontColor(1.0, 0.8, 0)	#SetFontColor(0.2, 0.2, 1.0)
		self.PositionText.SetText("(200, 800)")
		self.PositionText.Show()
		
		global TeleportHackMode
		self.ModeButton = ui.Button()
		self.ModeButton.SetParent(self)
		self.ModeButton.SetUpVisual("d:/ymir work/ui/public/middle_button_01.sub")
		self.ModeButton.SetOverVisual("d:/ymir work/ui/public/middle_button_02.sub")
		self.ModeButton.SetDownVisual("d:/ymir work/ui/public/middle_button_03.sub")
		self.ModeButton.SetText(TeleportHackMode)		
		self.ModeButton.SetEvent(lambda : self.ChangeMode())
		self.ModeButton.Show()
		
		self.Hide()
		
	def switch_state(self):
		if self.IsShow():
			self.Hide()
		else:
			self.Show()

	def ChangeMode(self):
		global TeleportHackMode
		if TeleportHackMode == "Teleport":
			TeleportHackMode = "Walk"
		else:
			TeleportHackMode = "Teleport"
		self.ModeButton.SetText(TeleportHackMode)
		
	def Hide(self):
		ui.ScriptWindow.Hide(self)

	def Show(self):			
		if self.AtlasMainWindow:
			(iSizeX, iSizeY, SizeX, SizeY) = GetCurrentMapSize()
			self.SetSize(iSizeX + 15, iSizeY + 38 + 30)
			self.board.SetSize(iSizeX + 15, iSizeY + 38 + 30)
			self.Line.SetPosition(7, iSizeY + 31)
			self.Line.SetSize(iSizeX, 0)
			self.ModeText.SetPosition(15, iSizeY + 38)
			self.ModeButton.SetPosition(55, iSizeY + 36)
			self.PositionText.SetPosition(125, iSizeY + 38)
			
			self.AtlasMainWindow.ShowAtlas()
			self.AtlasMainWindow.Show()
		ui.ScriptWindow.Show(self)

	def OnUpdate(self):
		(PlayerX, PlayerY, PlayerZ) = player.GetMainCharacterPosition()
		self.PositionText.SetText("(%s, %s)" % (int(PlayerX / 100), int(PlayerY / 100)))
	
		if background.GetCurrentMapName() != self.CurrentMapName:
			self.Show()
			self.CurrentMapName = background.GetCurrentMapName()
	
		miniMap.ShowAtlas()
		if not self.tooltipInfo:
			return

		self.tooltipInfo.Hide()

		if FALSE == self.board.IsIn():
			return

		(mouseX, mouseY) = wndMgr.GetMousePosition()
		(bFind, sName, iPosX, iPosY, dwTextColor, dwGuildID) = miniMap.GetAtlasInfo(mouseX, mouseY)

		(PosX, PosY) = self.GetGlobalPosition()
		
		(iSizeX, iSizeY, SizeX, SizeY) = GetCurrentMapSize()
		if not bFind:
			MapSizeX = miniMap.GetAtlasSize()[1]
			if MapSizeX == 0:
				size = 6
			else:
				size = DivideToFloat(SizeX * 256, miniMap.GetAtlasSize()[1])
			height = 30 * size
			width = 6 * size
			(sName, iPosX, iPosY, dwTextColor) = "", (mouseX - PosX) * size - width, (mouseY - PosY) * size - height, -8722595
			
		if iPosX < 0 or iPosY < 0 or iPosX > SizeX * 256 or iPosY > SizeY * 256:
			return

		self.tooltipInfo.SetText("%s(%d, %d)" % (sName, iPosX, iPosY))
		(x, y) = self.GetGlobalPosition()
		self.tooltipInfo.SetTooltipPosition(mouseX - x, mouseY - y)
		self.tooltipInfo.SetTextColor(dwTextColor)
		self.tooltipInfo.Show()
		self.tooltipInfo.SetTop()

	def OnPressEscapeKey(self):
		self.Hide()
		return TRUE
		
MapBuffer = {}		
def GetCurrentMapSize():
	global MapBuffer
	ActualMapName = background.GetCurrentMapName()
	if ActualMapName in MapBuffer:
		return MapBuffer[ActualMapName]
	else:
		(bGet, iSizeX, iSizeY) = miniMap.GetAtlasSize()
		GetMapData = str(m2k_lib.EterPackOperator("atlasinfo.txt").read())
		MapData = GetMapData.split("\n")
		for Map in MapData:
			try:
				MapName = Map.split("\t")[0]
				SizeX = int(Map.split("\t")[3])
				SizeY = int(Map.split("\t")[4])
				if MapName == ActualMapName:
					if iSizeX == 0 or iSizeY == 0:
						iSizeX = SizeX * 43
						iSizeY = SizeY * 43
					break
			except:
				pass
		MapBuffer[ActualMapName] = (iSizeX, iSizeY, SizeX, SizeY)
		return(iSizeX, iSizeY, SizeX, SizeY)
		
def GetTmpTeleport(DestX, DestY):
	(PlayerX, PlayerY, PlayerZ) = player.GetMainCharacterPosition()
	DifX = DestX - PlayerX
	DifY = DestY - PlayerY
	Vektor = DivideToFloat(2000, math.sqrt(DifX**2 + DifY**2))
	TempX = PlayerX + Vektor*DifX
	TempY = PlayerY + Vektor*DifY
	Count = DivideToFloat((DestX - PlayerX), (Vektor*DifX))
	return (TempX, TempY, Count)
		
def DivideToFloat(x, y):
	try:
		return x * (y**-1)
	except:
		return 0		
		

